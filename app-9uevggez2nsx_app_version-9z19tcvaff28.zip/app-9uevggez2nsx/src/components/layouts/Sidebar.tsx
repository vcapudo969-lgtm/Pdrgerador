import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Plus, 
  Settings, 
  Key, 
  FileText, 
  Wallet, 
  ArrowLeftRight, 
  User, 
  Users,
  UserMinus,
  Code,
  Share2, 
  AlertCircle,
  ShieldCheck,
  LogOut,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface NavItem {
  title: string;
  icon: React.ReactNode;
  href: string;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export function Sidebar() {
  const { profile, signOut } = useAuth();
  const location = useLocation();

  const sections: NavSection[] = [
    {
      title: 'PRINCIPAL',
      items: [
        { title: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" />, href: '/dashboard' },
      ],
    },
    {
      title: 'KEYS',
      items: [
        { title: 'Gerar Keys', icon: <Plus className="w-4 h-4" />, href: '/generate-keys' },
        { title: 'Gerenciar Keys', icon: <Settings className="w-4 h-4" />, href: '/manage-keys' },
      ],
    },
    {
      title: 'API',
      items: [
        { title: 'API Keys', icon: <Key className="w-4 h-4" />, href: '/api-keys' },
        { title: 'Docs API', icon: <Code className="w-4 h-4" />, href: '/api-docs' },
      ],
    },
    {
      title: 'CARTEIRA',
      items: [
        { title: 'Comprar Crédito', icon: <Wallet className="w-4 h-4" />, href: '/wallet' },
        { title: 'Transferir Créditos', icon: <ArrowLeftRight className="w-4 h-4" />, href: '/transfer-credits' },
      ],
    },
    {
      title: 'PERFIL',
      items: [
        { title: 'Meu Perfil', icon: <User className="w-4 h-4" />, href: '/profile' },
        { title: 'Link de Afiliado', icon: <Share2 className="w-4 h-4" />, href: '/affiliate' },
        { title: 'Revendedor', icon: <Users className="w-4 h-4" />, href: '/reseller' },
        { title: 'Reclamações', icon: <AlertCircle className="w-4 h-4" />, href: '/complaints' },
      ],
    }
  ];

  if (profile?.role === 'admin' || profile?.role === 'super_admin') {
    sections.push({
      title: 'ADMIN',
      items: [
        { title: 'APIs de Validação', icon: <ShieldCheck className="w-4 h-4" />, href: '/admin/apis' },
      ],
    });
  }

  if (profile?.role === 'super_admin') {
    sections.push({
      title: 'SUPER ADMIN',
      items: [
        { title: 'Gerenciar Admins', icon: <Users className="w-4 h-4" />, href: '/admin/users' },
        { title: 'Excluir Usuários', icon: <UserMinus className="w-4 h-4" />, href: '/admin/users' },
      ],
    });
  }

  return (
    <div className="w-56 flex flex-col h-screen bg-black sticky top-0 border-r border-white/5">
      <div className="p-5">
        <h1 className="text-lg font-bold flex items-center gap-2">
          <div className="w-7 h-7 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold shadow-[0_0_15px_rgba(34,197,94,0.3)] text-xs">P</div>
          <span className="text-white">Pdr gerador</span>
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto px-3 space-y-5 pb-20 scrollbar-hide">
        {sections.map((section) => (
          <div key={section.title} className="space-y-1">
            <div className="px-3 py-2 text-[9px] font-bold text-white/30 uppercase tracking-[0.15em]">
              {section.title}
            </div>
            <div className="space-y-0.5">
              {section.items.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 group",
                    location.pathname === item.href
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : "text-white/50 hover:bg-white/5 hover:text-white"
                  )}
                >
                  <div className={cn(
                    "p-1 rounded-lg transition-colors",
                    location.pathname === item.href ? "text-primary" : "text-white/40 group-hover:text-white"
                  )}>
                    {item.icon}
                  </div>
                  {item.title}
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-white/5 bg-black mt-auto">
        <div className="flex items-center gap-3 mb-4 px-1">
          <Avatar className="w-8 h-8 border-2 border-primary/20">
            <AvatarFallback className="bg-primary/10 text-primary font-bold text-xs">
              {profile?.username?.charAt(0).toUpperCase() || 'P'}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white leading-tight">{profile?.username || 'Usuário'}</span>
            <span className="text-[10px] text-primary font-bold tracking-wider">
              $ {profile?.credits?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0,00'}
            </span>
          </div>
        </div>
        <Button 
          variant="destructive" 
          className="w-full flex items-center gap-2 bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all rounded-xl h-9 font-bold text-xs"
          onClick={() => signOut()}
        >
          <LogOut className="w-3.5 h-3.5" />
          Sair
        </Button>
      </div>
    </div>
  );
}
