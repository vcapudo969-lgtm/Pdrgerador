import React from 'react';
import { Sidebar } from './Sidebar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAuth, type Profile } from '@/contexts/AuthContext';

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { profile } = useAuth();

  return (
    <div className="flex h-screen bg-black text-white selection:bg-primary/30">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex shrink-0">
        <Sidebar />
      </div>
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#050505]">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b border-white/5 bg-black/80 backdrop-blur-xl sticky top-0 z-50">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden hover:bg-white/5">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 border-r-white/5 bg-black">
              <Sidebar />
            </SheetContent>
          </Sheet>
          
          <h1 className="text-lg font-black tracking-tight">Pdr <span className="text-primary">gerador</span></h1>
          
          <Avatar className="w-8 h-8 border border-primary/20">
            <AvatarFallback className="bg-primary/10 text-primary text-[10px] font-black">
              {profile?.username?.charAt(0).toUpperCase() || 'P'}
            </AvatarFallback>
          </Avatar>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-10 scroll-smooth">
          <div className="max-w-5xl mx-auto space-y-10">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
