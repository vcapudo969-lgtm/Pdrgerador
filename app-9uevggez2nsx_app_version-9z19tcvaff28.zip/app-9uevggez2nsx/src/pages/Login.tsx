import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ShieldCheck, User, Lock, Loader2 } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Preencha todos os campos');
      return;
    }

    setLoading(true);
    const { error } = await signIn(email, password);

    if (error) {
      toast.error(error.message || 'Erro na autenticação');
      setLoading(false);
    } else {
      toast.success('Login realizado!');
      navigate('/dashboard');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 blur-[150px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/10 blur-[150px] rounded-full pointer-events-none"></div>

      <Card className="w-full max-w-sm border-white/5 bg-white/5 backdrop-blur-2xl relative z-10 shadow-2xl rounded-3xl overflow-hidden">
        <CardHeader className="text-center space-y-4 pt-8">
          <div className="mx-auto w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-primary-foreground shadow-[0_0_20px_rgba(34,197,94,0.3)]">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <CardTitle className="text-2xl font-bold tracking-tight text-white">Pdr <span className="text-primary">gerador</span></CardTitle>
            <CardDescription className="text-white/40 font-medium text-xs">
              Entre na sua conta para gerenciar suas keys
            </CardDescription>
          </div>
        </CardHeader>
        <form onSubmit={handleAuth}>
          <CardContent className="space-y-4 px-8">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white/60 font-bold ml-1 text-xs">E-mail</Label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20 group-focus-within:text-primary transition-all rounded-xl" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Seu e-mail"
                  className="h-11 pl-11 bg-white/5 border-white/10 focus:border-primary/50 transition-all rounded-xl text-white placeholder:text-white/10 text-sm"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-white/60 font-bold ml-1 text-xs">Senha</Label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20 group-focus-within:text-primary transition-colors" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  className="h-11 pl-11 bg-white/5 border-white/10 focus:border-primary/50 transition-all rounded-xl text-white placeholder:text-white/10 text-sm"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4 px-8 pb-10 pt-4">
            <Button className="w-full h-11 font-bold text-base rounded-xl shadow-xl shadow-primary/10 group overflow-hidden relative" type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Carregando...
                </>
              ) : (
                'Entrar no Painel'
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            </Button>
            
            <p className="text-[10px] text-center text-white/20 font-bold uppercase tracking-widest">
               Contate um administrador para criar sua conta
            </p>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
