import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Share2, 
  Copy, 
  TrendingUp, 
  Users, 
  Coins, 
  Zap,
  BadgeCheck,
  Gift,
  ExternalLink,
  Smartphone,
  Info
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

export default function AffiliatePage() {
  const { profile } = useAuth();
  const affiliateLink = profile?.affiliate_link || `https://pdrgerador.com/register?ref=${profile?.username}`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Link copiado para a área de transferência!');
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="space-y-1">
        <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
          <Share2 className="w-8 h-8 text-primary" /> Programa de <span className="text-primary">Afiliados</span>
        </h2>
        <p className="text-white/40 font-medium text-sm text-italic">Ganhe comissões indicando novos usuários para nossa plataforma.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl border-t-4 border-t-primary shadow-2xl">
            <CardHeader className="p-8 border-b border-white/5">
              <CardTitle className="text-xl font-black text-white flex items-center gap-2">
                <Gift className="w-6 h-6 text-primary" /> Seu Link de Afiliado
              </CardTitle>
              <CardDescription className="text-white/40 font-bold uppercase tracking-widest text-[10px]">Compartilhe este link e ganhe até 15% em todas as compras.</CardDescription>
            </CardHeader>
            <CardContent className="p-8 space-y-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative group">
                  <Input 
                    value={affiliateLink} 
                    readOnly 
                    className="h-14 bg-white/5 border-white/10 pr-12 font-bold text-white rounded-xl focus:border-primary/50 transition-all"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[9px] font-black uppercase tracking-widest text-primary/40">Link Pessoal</div>
                </div>
                <Button 
                  onClick={() => copyToClipboard(affiliateLink)}
                  className="h-14 px-8 font-black uppercase tracking-widest shadow-xl shadow-primary/20 text-xs gap-2 rounded-xl"
                >
                  <Copy className="w-4 h-4" /> Copiar Link
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                <div className="p-5 bg-white/5 rounded-2xl border border-white/5 space-y-2 group hover:border-primary/20 transition-all">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-2xl font-black text-white">42</p>
                    <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Indicações Totais</p>
                  </div>
                </div>
                <div className="p-5 bg-white/5 rounded-2xl border border-white/5 space-y-2 group hover:border-orange-500/20 transition-all">
                  <div className="w-10 h-10 bg-orange-500/10 rounded-xl flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-2xl font-black text-white">8.5%</p>
                    <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Taxa de Conversão</p>
                  </div>
                </div>
                <div className="p-5 bg-white/5 rounded-2xl border border-white/5 space-y-2 group hover:border-green-500/20 transition-all">
                  <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center text-green-500 group-hover:scale-110 transition-transform">
                    <Coins className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-2xl font-black text-white">$ 250,00</p>
                    <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Saldo para Resgate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-8 space-y-6">
            <h4 className="text-xl font-black text-white flex items-center gap-2 underline decoration-primary/30 decoration-4">
              <Zap className="w-6 h-6 text-primary" /> Como funciona o Programa?
            </h4>
            <div className="space-y-4">
                <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-black shrink-0">1</div>
                    <div className="space-y-1">
                        <p className="font-bold text-white uppercase text-xs">Compartilhe seu link</p>
                        <p className="text-white/40 text-xs leading-relaxed font-medium">Envie seu link único para amigos, em fóruns ou redes sociais. Qualquer um que se cadastrar através dele será seu afiliado.</p>
                    </div>
                </div>
                <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-black shrink-0">2</div>
                    <div className="space-y-1">
                        <p className="font-bold text-white uppercase text-xs">Aguarde as compras</p>
                        <p className="text-white/40 text-xs leading-relaxed font-medium">Sempre que um de seus indicados comprar créditos na plataforma, uma porcentagem do valor será creditada na sua conta de afiliado.</p>
                    </div>
                </div>
                <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-black shrink-0">3</div>
                    <div className="space-y-1">
                        <p className="font-bold text-white uppercase text-xs">Resgate seus ganhos</p>
                        <p className="text-white/40 text-xs leading-relaxed font-medium">Quando atingir o valor mínimo de $ 50,00 em saldo de comissão, você poderá solicitar o resgate diretamente para sua conta PIX.</p>
                    </div>
                </div>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-8 space-y-6 border-l-4 border-l-primary shadow-2xl">
             <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary border border-primary/10">
                <BadgeCheck className="w-8 h-8" />
             </div>
             <div className="space-y-2">
                <h4 className="text-lg font-black text-white uppercase tracking-tighter">Nível de Afiliado</h4>
                <p className="text-3xl font-black text-primary">MASTER</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Comissão Atual: 15%</p>
             </div>
             <div className="pt-4 border-t border-white/5 space-y-4">
                <p className="text-xs text-white/50 leading-relaxed font-bold uppercase tracking-wider">Próximo Nível: <span className="text-white">DIAMANTE (20%)</span></p>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-primary w-1/2 shadow-[0_0_10px_rgba(var(--primary),0.5)]"></div>
                </div>
                <p className="text-[9px] text-white/20 font-black uppercase tracking-[0.2em]">Indique mais 58 usuários para subir</p>
             </div>
          </Card>

          <Card className="border-white/5 bg-primary/5 p-6 space-y-4 rounded-2xl border border-primary/10 relative overflow-hidden group">
             <div className="absolute -right-8 -top-8 w-24 h-24 bg-primary/10 rounded-full blur-3xl group-hover:scale-150 transition-all duration-700"></div>
             <div className="flex items-center gap-2 text-primary font-black uppercase text-[10px] tracking-widest">
                <Info className="w-4 h-4" /> Regras de Afiliado
             </div>
             <ul className="space-y-2 list-none text-[9px] text-white/40 font-bold uppercase tracking-widest leading-relaxed">
                <li className="flex items-center gap-2"><div className="w-1 h-1 bg-primary rounded-full"></div> Proibido auto-indicação</li>
                <li className="flex items-center gap-2"><div className="w-1 h-1 bg-primary rounded-full"></div> Pagamentos processados em até 48h</li>
                <li className="flex items-center gap-2"><div className="w-1 h-1 bg-primary rounded-full"></div> Mínimo de resgate: $ 50,00</li>
                <li className="flex items-center gap-2"><div className="w-1 h-1 bg-primary rounded-full"></div> Contas fake serão banidas</li>
             </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
