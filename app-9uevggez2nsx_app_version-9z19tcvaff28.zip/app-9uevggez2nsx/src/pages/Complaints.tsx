import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Complaint } from '../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  AlertCircle, 
  Send, 
  MessageSquare, 
  Clock, 
  CheckCircle2, 
  HelpCircle,
  Loader2,
  Inbox
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

export default function ComplaintsPage() {
  const { profile } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  
  // Form
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (profile) {
      api.getMyComplaints(profile.id).then(data => {
        setComplaints(data);
        setLoading(false);
      });
    }
  }, [profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    if (!subject || !message) {
      toast.error('Preencha todos os campos');
      return;
    }

    setSending(true);
    try {
      await api.createComplaint(profile.id, subject, message);
      toast.success('Sua reclamação foi enviada com sucesso!');
      setSubject('');
      setMessage('');
      const data = await api.getMyComplaints(profile.id);
      setComplaints(data);
    } catch (err) {
      toast.error('Erro ao enviar reclamação');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-bold tracking-tight">Reclamações & Suporte</h2>
        <p className="text-muted-foreground">Teve algum problema? Envie sua reclamação para que possamos ajudar.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form Column */}
        <Card className="border-border/40 bg-card/40 backdrop-blur-sm h-fit shadow-2xl overflow-hidden border-t-4 border-t-primary">
          <CardHeader className="pb-4">
             <CardTitle className="text-xl font-black flex items-center gap-3">
               <MessageSquare className="w-6 h-6 text-primary" /> Nova Mensagem
             </CardTitle>
             <CardDescription>Explique o ocorrido detalhadamente para uma resposta mais rápida.</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6 pt-6">
               <div className="space-y-2">
                 <Label htmlFor="subject" className="font-bold">Assunto do Problema</Label>
                 <Input 
                   id="subject" 
                   placeholder="Ex: Key não funciona, erro ao gerar keys..." 
                   value={subject}
                   onChange={(e) => setSubject(e.target.value)}
                   className="h-12 bg-background/50 border-border/40 font-bold focus:border-primary/50"
                 />
               </div>
               <div className="space-y-2">
                 <Label htmlFor="message" className="font-bold">Descrição Detalhada</Label>
                 <Textarea 
                   id="message" 
                   placeholder="Conte-nos o que aconteceu..." 
                   rows={6}
                   value={message}
                   onChange={(e) => setMessage(e.target.value)}
                   className="bg-background/50 border-border/40 min-h-[150px] focus:border-primary/50"
                 />
               </div>
            </CardContent>
            <CardFooter className="bg-muted/10 p-6 border-t border-border/20">
               <Button type="submit" className="w-full h-12 font-black shadow-lg shadow-primary/20" disabled={sending}>
                 {sending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                 Enviar para Análise
               </Button>
            </CardFooter>
          </form>
        </Card>

        {/* History Column */}
        <div className="space-y-6">
           <h3 className="text-xl font-black flex items-center gap-2">
             <Inbox className="w-5 h-5 text-primary" /> Seu Histórico
           </h3>
           
           {loading ? (
             <div className="space-y-4">
               {[1, 2, 3].map(i => <div key={i} className="h-32 bg-muted/20 animate-pulse rounded-2xl border border-border/10"></div>)}
             </div>
           ) : complaints.length > 0 ? (
             <div className="space-y-4">
               {complaints.map((complaint) => (
                 <Card key={complaint.id} className="border-border/40 bg-card/40 backdrop-blur-sm group hover:border-primary/30 transition-all">
                    <CardHeader className="p-5 pb-2">
                       <div className="flex items-center justify-between">
                         <Badge 
                           variant={complaint.status === 'pending' ? 'outline' : 'default'}
                           className={complaint.status === 'pending' ? 'border-orange-500/30 text-orange-500 bg-orange-500/5' : 'bg-green-500/20 text-green-500 border-green-500/30'}
                         >
                           {complaint.status === 'pending' ? <Clock className="w-3 h-3 mr-1" /> : <CheckCircle2 className="w-3 h-3 mr-1" />}
                           {complaint.status === 'pending' ? 'Em Análise' : 'Resolvido'}
                         </Badge>
                         <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{new Date(complaint.created_at).toLocaleDateString('pt-BR')}</span>
                       </div>
                       <CardTitle className="text-base font-black mt-2">{complaint.subject}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-5 pt-0">
                       <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">{complaint.message}</p>
                    </CardContent>
                 </Card>
               ))}
             </div>
           ) : (
             <div className="bg-muted/10 border-2 border-dashed border-border/20 rounded-3xl p-12 text-center flex flex-col items-center space-y-4">
                <div className="p-4 bg-muted/20 rounded-full">
                   <HelpCircle className="w-8 h-8 text-muted-foreground/50" />
                </div>
                <div className="space-y-1">
                  <p className="font-black text-muted-foreground">Nenhuma solicitação</p>
                  <p className="text-xs text-muted-foreground/60 max-w-xs leading-relaxed">Suas mensagens enviadas ao suporte aparecerão aqui para acompanhamento.</p>
                </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
}
