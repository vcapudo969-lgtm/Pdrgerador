import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Profile } from '../../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Users, 
  Plus, 
  Minus, 
  UserPlus, 
  Search, 
  MoreHorizontal,
  Wallet,
  ShieldCheck,
  ShieldAlert,
  UserMinus,
  Trash2, 
  AlertTriangle,
  Clock
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function UserManagement() {
  const { profile: adminProfile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Create User State
  const [newEmail, setNewEmail] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Credit Management State
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [creditAmount, setCreditAmount] = useState<number>(0);
  const [creditDialogOpen, setCreditDialogOpen] = useState(false);
  const [creditAction, setCreditAction] = useState<'add' | 'remove'>('add');

  // Deletion / Demotion Confirmation
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [demoteConfirmOpen, setDemoteConfirmOpen] = useState(false);

  // Bulk Time Management
  const [timeAmount, setTimeAmount] = useState<number>(0);
  const [timeDialogOpen, setTimeDialogOpen] = useState(false);
  const [isUpdatingTime, setIsUpdatingTime] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const data = await api.getAllUsers();
      setUsers(data);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Erro ao carregar usuários');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async () => {
    if (!newEmail || !newPassword) {
      toast.error('E-mail e senha são obrigatórios');
      return;
    }
    setIsCreating(true);
    try {
      await api.adminCreateUser(newEmail, newPassword, newUsername || newEmail.split('@')[0]);
      toast.success('Usuário criado com sucesso!');
      setCreateDialogOpen(false);
      setNewEmail('');
      setNewUsername('');
      setNewPassword('');
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao criar usuário');
    } finally {
      setIsCreating(false);
    }
  };

  const handleUpdateCredits = async () => {
    if (!selectedUser || creditAmount <= 0) return;
    
    try {
      await api.adminUpdateCredits(selectedUser.id, creditAmount, creditAction);
      toast.success(`Créditos ${creditAction === 'add' ? 'adicionados' : 'removidos'} com sucesso!`);
      setCreditDialogOpen(false);
      setCreditAmount(0);
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao atualizar créditos');
    }
  };

  const handlePromote = async (userId: string) => {
    try {
      await api.promoteToAdmin(userId);
      toast.success('Usuário promovido a Administrador');
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao promover usuário');
    }
  };

  const handleDemote = async () => {
    if (!selectedUser) return;
    try {
      await api.demoteFromAdmin(selectedUser.id);
      toast.success('Administrador removido para usuário comum');
      setDemoteConfirmOpen(false);
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao remover privilégios');
    }
  };

  const handleDelete = async () => {
    if (!selectedUser) return;
    setIsDeleting(true);
    try {
      await api.deleteUser(selectedUser.id);
      toast.success('Usuário excluído com sucesso');
      setDeleteConfirmOpen(false);
      fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao excluir usuário');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleAddTimeGlobally = async () => {
    if (timeAmount <= 0) {
      toast.error('Informe uma quantidade válida de horas');
      return;
    }
    setIsUpdatingTime(true);
    try {
      await api.addTimeToAllActiveKeys(timeAmount);
      toast.success(`Tempo adicionado a todas as keys ativas!`);
      setTimeDialogOpen(false);
      setTimeAmount(0);
    } catch (error: any) {
      toast.error(error.message || 'Erro ao atualizar tempo global');
    } finally {
      setIsUpdatingTime(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.username?.toLowerCase().includes(search.toLowerCase()) || 
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  if (adminProfile?.role !== 'admin' && adminProfile?.role !== 'super_admin') {
    return <div className="p-10 text-center font-bold text-red-500">Acesso negado. Apenas administradores.</div>;
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" /> Gerenciar Usuários
          </h2>
          <p className="text-white/40 font-medium text-sm">Controle total sobre os usuários e créditos do sistema.</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2">
           <Dialog open={timeDialogOpen} onOpenChange={setTimeDialogOpen}>
             <DialogTrigger asChild>
               <Button variant="outline" className="h-10 px-4 font-bold rounded-xl gap-2 border-primary/20 text-primary hover:bg-primary/10 transition-all text-xs">
                 <Clock className="w-4 h-4" /> Adicionar Tempo Global
               </Button>
             </DialogTrigger>
             <DialogContent className="bg-black border-white/10 text-white rounded-2xl">
               <DialogHeader>
                 <DialogTitle className="text-lg font-bold flex items-center gap-2">
                   <Clock className="w-5 h-5 text-primary" /> 
                   Acrescentar Tempo
                 </DialogTitle>
                 <CardDescription className="text-white/40 text-xs">
                   Isso adicionará tempo a <span className="text-primary font-bold">TODAS</span> as keys com status 'Ativa'.
                 </CardDescription>
               </DialogHeader>
               <div className="space-y-4 py-4">
                 <div className="space-y-2">
                   <Label className="text-xs">Quantidade de Horas a Acrescentar</Label>
                   <Input 
                     type="number" 
                     min="1"
                     value={timeAmount || ''} 
                     onChange={e => setTimeAmount(parseInt(e.target.value) || 0)}
                     placeholder="ex: 24 (para 1 dia)"
                     className="bg-white/5 border-white/10 h-11 text-base font-bold"
                   />
                 </div>
               </div>
               <DialogFooter>
                 <Button variant="outline" onClick={() => setTimeDialogOpen(false)} className="border-white/10 h-10 text-xs">Cancelar</Button>
                 <Button 
                   onClick={handleAddTimeGlobally} 
                   disabled={isUpdatingTime}
                   className="font-bold bg-primary text-primary-foreground h-10 text-xs"
                 >
                   {isUpdatingTime ? 'Atualizando...' : 'Confirmar Adição'}
                 </Button>
               </DialogFooter>
             </DialogContent>
           </Dialog>

           <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
             <DialogTrigger asChild>
               <Button className="h-10 px-4 font-bold rounded-xl gap-2 shadow-xl shadow-primary/10 text-xs">
                 <UserPlus className="w-4 h-4" /> Criar Usuário
               </Button>
             </DialogTrigger>
             <DialogContent className="bg-black border-white/10 text-white rounded-2xl">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold">Adicionar Novo Usuário</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs">E-mail *</Label>
                <Input 
                  id="email" 
                  type="email"
                  value={newEmail} 
                  onChange={e => setNewEmail(e.target.value)}
                  placeholder="ex: pedro@gmail.com"
                  className="bg-white/5 border-white/10 h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username" className="text-xs">Nome de Exibição (Opcional)</Label>
                <Input 
                  id="username" 
                  value={newUsername} 
                  onChange={e => setNewUsername(e.target.value)}
                  placeholder="ex: pedro_cheats"
                  className="bg-white/5 border-white/10 h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-xs">Senha *</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={newPassword} 
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="bg-white/5 border-white/10 h-11"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)} className="border-white/10 h-10 text-xs">Cancelar</Button>
              <Button onClick={handleCreateUser} disabled={isCreating} className="font-bold h-10 text-xs">
                {isCreating ? 'Criando...' : 'Criar Conta'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      </div>

      <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
        <CardHeader className="pb-0 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
            <Input 
              placeholder="Pesquisar por username ou email..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 bg-white/5 border-white/10 h-10 rounded-xl text-sm"
            />
          </div>
        </CardHeader>
        <CardContent className="pt-4 p-0">
          <div className="rounded-xl border border-white/5 overflow-hidden mx-4 mb-4">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="text-white font-bold text-[9px] uppercase tracking-widest h-10">Usuário</TableHead>
                  <TableHead className="text-white font-bold text-[9px] uppercase tracking-widest h-10">Role</TableHead>
                  <TableHead className="text-white font-bold text-[9px] uppercase tracking-widest text-right h-10">Créditos</TableHead>
                  <TableHead className="text-white font-bold text-[9px] uppercase tracking-widest text-right h-10">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={4} className="text-center py-10 text-white/40 text-xs font-bold uppercase tracking-widest">Carregando usuários...</TableCell></TableRow>
                ) : filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                      <TableCell className="py-3">
                        <div className="flex flex-col">
                          <span className="font-bold text-white group-hover:text-primary transition-colors text-xs">{user.username}</span>
                          <span className="text-[10px] text-white/30">{user.email}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-3">
                        <Badge variant={user.role === 'admin' ? 'default' : 'outline'} className={cn(
                          "capitalize rounded-md text-[9px] px-1.5 py-0",
                          user.role === 'admin' ? "bg-primary text-primary-foreground" : "border-white/10 text-white/40"
                        )}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-bold text-primary text-xs py-3">
                        {user.credits?.toLocaleString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-right py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="hover:bg-white/10">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-black border-white/10 text-white">
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer focus:bg-primary focus:text-primary-foreground"
                              onClick={() => {
                                setSelectedUser(user);
                                setCreditAction('add');
                                setCreditDialogOpen(true);
                              }}
                            >
                              <Plus className="w-4 h-4" /> Adicionar Créditos
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer focus:bg-red-500 focus:text-white"
                              onClick={() => {
                                setSelectedUser(user);
                                setCreditAction('remove');
                                setCreditDialogOpen(true);
                              }}
                            >
                              <Minus className="w-4 h-4" /> Remover Créditos
                            </DropdownMenuItem>

                            {adminProfile?.role === 'super_admin' && user.role === 'user' && (
                                <DropdownMenuItem 
                                    className="gap-2 cursor-pointer focus:bg-primary focus:text-primary-foreground"
                                    onClick={() => handlePromote(user.id)}
                                >
                                    <ShieldCheck className="w-4 h-4" /> Tornar Administrador
                                </DropdownMenuItem>
                            )}

                            {adminProfile?.role === 'super_admin' && user.role === 'admin' && (
                                <DropdownMenuItem 
                                    className="gap-2 cursor-pointer focus:bg-orange-500 focus:text-white"
                                    onClick={() => {
                                      setSelectedUser(user);
                                      setDemoteConfirmOpen(true);
                                    }}
                                >
                                    <ShieldAlert className="w-4 h-4" /> Remover Administrador
                                </DropdownMenuItem>
                            )}

                            {adminProfile?.role === 'super_admin' && user.id !== adminProfile.id && (
                              <>
                                <DropdownMenuSeparator className="bg-white/5" />
                                <DropdownMenuItem 
                                    className="gap-2 cursor-pointer focus:bg-red-500 focus:text-white"
                                    onClick={() => {
                                      setSelectedUser(user);
                                      setDeleteConfirmOpen(true);
                                    }}
                                >
                                    <Trash2 className="w-4 h-4" /> Excluir Usuário
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow><TableCell colSpan={4} className="text-center py-10 text-white/40">Nenhum usuário encontrado.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Credit Management Dialog */}
      <Dialog open={creditDialogOpen} onOpenChange={setCreditDialogOpen}>
        <DialogContent className="bg-black border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-black flex items-center gap-2">
              <Wallet className="w-6 h-6 text-primary" /> 
              {creditAction === 'add' ? 'Adicionar' : 'Remover'} Créditos
            </DialogTitle>
            <CardDescription className="text-white/40">
              Usuário: <span className="text-white font-bold">{selectedUser?.username}</span>
            </CardDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Quantidade de Créditos</Label>
              <Input 
                type="number" 
                min="1"
                value={creditAmount || ''} 
                onChange={e => setCreditAmount(parseInt(e.target.value) || 0)}
                placeholder="ex: 500"
                className="bg-white/5 border-white/10 h-12 text-lg font-black"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreditDialogOpen(false)} className="border-white/10">Cancelar</Button>
            <Button 
              onClick={handleUpdateCredits} 
              className={cn(
                "font-bold",
                creditAction === 'remove' ? "bg-red-500 hover:bg-red-600" : ""
              )}
            >
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog for Demotion */}
      <AlertDialog open={demoteConfirmOpen} onOpenChange={setDemoteConfirmOpen}>
        <AlertDialogContent className="bg-black border-white/10 text-white rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-black flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-orange-500" />
              Remover privilégios admin?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-white/40 font-bold">
              Deseja realmente remover os privilégios de administrador de <span className="text-white">{selectedUser?.username}</span>? Ele voltará a ser um usuário comum.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-xl">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDemote} className="bg-orange-500 hover:bg-orange-600 text-white font-black rounded-xl">
              Confirmar Remoção
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirmation Dialog for Deletion */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent className="bg-black border-white/10 text-white rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-black flex items-center gap-2 text-red-500">
              <AlertTriangle className="w-6 h-6" />
              Excluir Usuário Permanente?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-white/40 font-bold">
              Esta ação é <span className="text-red-500">irreversível</span>. Todos os dados associados a <span className="text-white">{selectedUser?.username}</span> serão perdidos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-xl" disabled={isDeleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={(e) => {
                e.preventDefault();
                handleDelete();
              }} 
              disabled={isDeleting}
              className="bg-red-500 hover:bg-red-600 text-white font-black rounded-xl"
            >
              {isDeleting ? 'Excluindo...' : 'Excluir Definitivamente'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
