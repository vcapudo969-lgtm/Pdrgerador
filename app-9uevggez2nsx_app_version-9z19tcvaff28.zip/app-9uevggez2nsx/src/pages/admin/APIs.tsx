import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { ValidationEndpoint, LoginVersion, ValidityOption } from '../../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Globe, 
  Shield, 
  Plus, 
  Trash2, 
  Zap, 
  Clock, 
  Terminal,
  ExternalLink,
  Code,
  Info,
  Copy,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export default function APIsManagement() {
  const { profile } = useAuth();
  const [endpoints, setEndpoints] = useState<ValidationEndpoint[]>([]);
  const [versions, setVersions] = useState<LoginVersion[]>([]);
  const [validityOptions, setValidityOptions] = useState<ValidityOption[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Create Endpoint State
  const [newName, setNewName] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Bulk Time Management
  const [timeAmount, setTimeAmount] = useState<number>(0);
  const [timeDialogOpen, setTimeDialogOpen] = useState(false);
  const [isUpdatingTime, setIsUpdatingTime] = useState(false);

  const masterToken = "JACINTOPINTOEREBOLO";
  const externalApiUrl = "https://afquvklzmaanwnxcaqip.supabase.co/functions/v1/generate-bot-key-external";
  const botApiEndpoint = "https://afquvklzmaanwnxcaqip.supabase.co/functions/v1/bot-api";

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [endpointsData, versionsData, validityOptionsData] = await Promise.all([
        api.getValidationEndpoints(),
        api.getLoginVersions(),
        api.getValidityOptions()
      ]);
      setEndpoints(endpointsData);
      setVersions(versionsData);
      setValidityOptions(validityOptionsData);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const fetchEndpoints = async () => {
    try {
      const data = await api.getValidationEndpoints();
      setEndpoints(data);
    } catch (error) {
      console.error('Error fetching endpoints:', error);
      toast.error('Erro ao carregar endpoints');
    }
  };

  const handleCreateEndpoint = async () => {
    if (!newName || !newUrl) {
      toast.error('Preencha todos os campos');
      return;
    }
    try {
      await api.createValidationEndpoint(newName, newUrl);
      toast.success('Endpoint adicionado com sucesso!');
      setCreateDialogOpen(false);
      setNewName('');
      setNewUrl('');
      fetchEndpoints();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao adicionar endpoint');
    }
  };

  const handleDeleteEndpoint = async (id: string) => {
    try {
      await api.deleteValidationEndpoint(id);
      toast.success('Endpoint removido');
      fetchEndpoints();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao remover endpoint');
    }
  };

  const handleToggleEndpoint = async (id: string, currentStatus: boolean) => {
    try {
      await api.toggleValidationEndpoint(id, currentStatus);
      toast.success(`Endpoint ${currentStatus ? 'desativado' : 'ativado'}`);
      fetchEndpoints();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao atualizar endpoint');
    }
  };

  const handleAddTimeGlobally = async () => {
    if (timeAmount <= 0) {
      toast.error('Informe uma quantidade válida de horas');
      return;
    }
    setIsUpdatingTime(true);
    try {
      await api.addTimeToAllActiveKeys(timeAmount);
      toast.success(`Tempo adicionado a todas as keys ativas!`);
      setTimeDialogOpen(false);
      setTimeAmount(0);
    } catch (error: any) {
      toast.error(error.message || 'Erro ao atualizar tempo global');
    } finally {
      setIsUpdatingTime(false);
    }
  };

  const copyToClipboard = (text: string, msg: string) => {
    navigator.clipboard.writeText(text);
    toast.success(msg);
  };

  if (profile?.role !== 'admin' && profile?.role !== 'super_admin') {
    return <div className="p-10 text-center font-bold text-red-500">Acesso negado. Apenas administradores.</div>;
  }

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
            <Zap className="w-8 h-8 text-primary" /> APIs de <span className="text-primary">Validação</span>
          </h2>
          <p className="text-white/40 font-medium text-sm">Gerencie endpoints externos e integrações de bots.</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2">
           <Dialog open={timeDialogOpen} onOpenChange={setTimeDialogOpen}>
             <DialogTrigger asChild>
               <Button variant="outline" className="h-11 px-6 font-black rounded-xl gap-2 border-primary/20 text-primary hover:bg-primary/10 transition-all text-xs uppercase tracking-widest">
                 <Clock className="w-4 h-4" /> Acrescentar Tempo Global
               </Button>
             </DialogTrigger>
             <DialogContent className="bg-black border-white/10 text-white rounded-2xl shadow-2xl">
               <DialogHeader>
                 <DialogTitle className="text-lg font-bold flex items-center gap-2">
                   <Clock className="w-5 h-5 text-primary" /> 
                   Acrescentar Tempo Global
                 </DialogTitle>
                 <CardDescription className="text-white/40 text-xs font-bold leading-relaxed pt-2">
                   Isso adicionará tempo a <span className="text-primary underline">TODAS</span> as keys que estão com o status 'Ativa'. 
                   Útil para compensar manutenções ou promoções.
                 </CardDescription>
               </DialogHeader>
               <div className="space-y-4 py-4">
                 <div className="space-y-2">
                   <Label className="text-xs font-black uppercase tracking-widest text-white/60">Quantidade de Horas</Label>
                   <Input 
                     type="number" 
                     min="1"
                     value={timeAmount || ''} 
                     onChange={e => setTimeAmount(parseInt(e.target.value) || 0)}
                     placeholder="ex: 24 (para 1 dia)"
                     className="bg-white/5 border-white/10 h-12 text-base font-black text-primary focus:border-primary/50 transition-all"
                   />
                 </div>
               </div>
               <DialogFooter>
                 <Button variant="outline" onClick={() => setTimeDialogOpen(false)} className="border-white/10 h-11 text-xs uppercase tracking-widest font-bold">Cancelar</Button>
                 <Button 
                   onClick={handleAddTimeGlobally} 
                   disabled={isUpdatingTime}
                   className="font-black bg-primary text-primary-foreground h-11 text-xs uppercase tracking-widest shadow-lg shadow-primary/20"
                 >
                   {isUpdatingTime ? 'Atualizando...' : 'Confirmar Adição'}
                 </Button>
               </DialogFooter>
             </DialogContent>
           </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Validation Endpoints Section */}
        <div className="space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl h-full flex flex-col">
            <CardHeader className="p-6 border-b border-white/5 bg-white/5">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-lg font-black text-white flex items-center gap-2">
                    <Globe className="w-5 h-5 text-primary" /> Endpoints Externos
                  </CardTitle>
                  <CardDescription className="text-white/40 text-xs font-bold">Configure onde seu sistema deve enviar validações.</CardDescription>
                </div>
                <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="h-9 px-4 font-black rounded-lg gap-2 shadow-xl shadow-primary/10 text-[10px] uppercase tracking-widest">
                      <Plus className="w-3 h-3" /> Adicionar
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black border-white/10 text-white rounded-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-lg font-bold">Adicionar Endpoint</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label className="text-xs uppercase tracking-widest text-white/50">Nome Identificador</Label>
                        <Input 
                          value={newName} 
                          onChange={e => setNewName(e.target.value)}
                          placeholder="ex: API Produção"
                          className="bg-white/5 border-white/10 h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs uppercase tracking-widest text-white/50">URL da API</Label>
                        <Input 
                          value={newUrl} 
                          onChange={e => setNewUrl(e.target.value)}
                          placeholder="https://sua-api.com/validate"
                          className="bg-white/5 border-white/10 h-11"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setCreateDialogOpen(false)} className="border-white/10 h-10 text-xs font-bold">Cancelar</Button>
                      <Button onClick={handleCreateEndpoint} className="font-black h-10 text-xs uppercase tracking-widest">Salvar Endpoint</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-auto max-h-[400px]">
              <Table>
                <TableHeader className="bg-white/5 sticky top-0 z-10">
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead className="text-white font-black text-[9px] uppercase tracking-widest h-10">Endpoint</TableHead>
                    <TableHead className="text-white font-black text-[9px] uppercase tracking-widest h-10">Status</TableHead>
                    <TableHead className="text-white font-black text-[9px] uppercase tracking-widest text-right h-10 px-6">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-10 text-white/20 font-bold uppercase tracking-widest text-[10px]">Carregando...</TableCell></TableRow>
                  ) : endpoints.length > 0 ? (
                    endpoints.map((ep) => (
                      <TableRow key={ep.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                        <TableCell className="py-4">
                          <div className="flex flex-col gap-1">
                            <span className="font-bold text-white group-hover:text-primary transition-colors text-xs">{ep.name}</span>
                            <span className="text-[10px] text-white/30 font-mono flex items-center gap-1">
                              <ExternalLink className="w-2.5 h-2.5" /> {ep.url}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="py-4">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className={cn(
                              "h-7 px-2 rounded-md flex items-center gap-2 text-[10px] font-black uppercase tracking-widest",
                              ep.is_active ? "text-primary hover:bg-primary/10" : "text-white/20 hover:bg-white/5"
                            )}
                            onClick={() => handleToggleEndpoint(ep.id, ep.is_active)}
                          >
                            {ep.is_active ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                            {ep.is_active ? "Ativo" : "Inativo"}
                          </Button>
                        </TableCell>
                        <TableCell className="py-4 text-right px-6">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-white/20 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                            onClick={() => handleDeleteEndpoint(ep.id)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow><TableCell colSpan={3} className="text-center py-10 text-white/20 font-bold uppercase tracking-widest text-[10px]">Nenhum endpoint configurado</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Bot Integration Section */}
        <div className="space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl h-full flex flex-col overflow-hidden">
            <CardHeader className="p-6 border-b border-white/5 bg-primary/5">
              <div className="space-y-1">
                <CardTitle className="text-lg font-black text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-primary" /> Integração para <span className="text-primary">Bots</span>
                </CardTitle>
                <CardDescription className="text-white/40 text-xs font-bold">Como bots externos devem usar a API de geração.</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-8 flex-1 overflow-auto">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Shield className="w-3 h-3 text-primary" /> Master Token
                  </h4>
                  <Badge className="bg-primary/20 text-primary border-none font-black text-[9px] uppercase tracking-widest">Admin Only</Badge>
                </div>
                <div className="flex items-center gap-3 bg-white/5 p-4 rounded-xl border border-white/10 group hover:border-primary/30 transition-all cursor-pointer relative overflow-hidden"
                     onClick={() => copyToClipboard(masterToken, 'Token copiado!')}>
                  <div className="absolute left-0 top-0 w-1 h-full bg-primary opacity-30"></div>
                  <code className="text-primary font-mono text-sm tracking-wider font-black">{masterToken}</code>
                  <Copy className="ml-auto w-4 h-4 text-white/20 group-hover:text-primary transition-all" />
                </div>
                <p className="text-[10px] text-white/30 font-bold leading-relaxed italic">
                  * Este token é fixo e universal para bots. Mantenha em segredo absoluto.
                </p>
              </div>

              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em] flex items-center gap-2">
                  <Terminal className="w-3 h-3 text-primary" /> Comandos no Bot
                </h4>
                <div className="space-y-3">
                   <div className="p-4 bg-[#0a0a0a] rounded-xl border border-white/5 space-y-2">
                     <p className="text-[10px] font-black text-primary uppercase tracking-widest">Exemplo de Uso (Discord/Telegram)</p>
                     <p className="text-xs font-mono text-white/70">
                       <span className="text-primary">!gerar</span> MyCheat <span className="text-primary text-[10px] underline">pedroxit@email.com</span>
                     </p>
                     <div className="pt-2 border-t border-white/5 mt-2">
                        <p className="text-[9px] text-white/30 font-bold uppercase">Chamada de API correspondente:</p>
                        <pre className="text-[9px] text-green-500 font-mono bg-black/50 p-2 rounded-md mt-2 overflow-x-auto">
{`POST ${externalApiUrl}
{
  "bot_name": "MyCheat",
  "token": "${masterToken}",
  "target_username": "pedroxit@email.com",
  "version_name": "Lite",
  "validity_hours": 24,
  "devices": 1
}`}
                        </pre>
                     </div>
                   </div>
                </div>
                   
                   <div className="p-4 bg-[#0a0a0a] rounded-xl border border-white/5 space-y-2">
                      <p className="text-[10px] font-black text-primary uppercase tracking-widest">Validar Status (Bot)</p>
                      <pre className="text-[9px] text-green-500 font-mono bg-black/50 p-2 rounded-md mt-2 overflow-x-auto">
{`POST ${botApiEndpoint}/bot-check
{
  "key": "KEY-AQUI",
  "token": "${masterToken}"
}`}
                      </pre>
                      <p className="text-[9px] text-white/30 font-bold uppercase pt-1">Retorna mensagens amigáveis: "✅ Ativa" ou "❌ Expirada".</p>
                   </div>
                   
                   <div className="p-4 bg-[#0a0a0a] rounded-xl border border-white/5 space-y-2">
                      <p className="text-[10px] font-black text-primary uppercase tracking-widest">Ações Rápidas (Pausar/Resetar/Banir)</p>
                      <pre className="text-[9px] text-green-500 font-mono bg-black/50 p-2 rounded-md mt-2 overflow-x-auto">
{`POST ${botApiEndpoint}/manage
{
  "key": "KEY-AQUI",
  "action": "reset",
  "token": "${masterToken}" 
}`}
                      </pre>
                      <p className="text-[9px] text-white/30 font-bold uppercase pt-1 italic">Pode usar "token" ou "master_key" no corpo.</p>
                   </div>


                    <div className="p-4 bg-[#0a0a0a] rounded-xl border border-white/5 space-y-4">
                      <div>
                        <p className="text-[10px] font-black text-primary uppercase tracking-widest">Fluxo Interativo e Opções</p>
                        <p className="text-[10px] text-white/40 leading-relaxed pt-1">
                          Para fluxos interativos:
                          1. O bot chama <code className="text-primary text-[9px]">GET {externalApiUrl}</code> para listar opções.
                          2. O bot envia <code className="text-primary text-[9px]">version_name</code> e <code className="text-primary text-[9px]">validity_hours</code> no POST.
                        </p>
                      </div>
                      
                      <div className="pt-4 border-t border-white/5 space-y-4">
                        <div className="space-y-2">
                          <p className="text-[9px] font-black text-white/30 uppercase tracking-widest flex items-center gap-2">
                            <Info className="w-3 h-3 text-primary" /> Versões (version_name):
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {versions.length > 0 ? versions.map(v => (
                              <Badge key={v.id} variant="outline" className="bg-primary/5 border-primary/20 text-primary text-[8px] h-5 px-2 font-black uppercase tracking-widest">{v.name}</Badge>
                            )) : <span className="text-[9px] text-white/20 italic">Carregando versões...</span>}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <p className="text-[9px] font-black text-white/30 uppercase tracking-widest flex items-center gap-2">
                            <Clock className="w-3 h-3 text-primary" /> Validades (validity_hours):
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {validityOptions.length > 0 ? validityOptions.map(v => (
                              <Badge key={v.id} variant="outline" className="bg-primary/5 border-primary/20 text-primary text-[8px] h-5 px-2 font-black uppercase tracking-widest">{v.hours}H ({v.label})</Badge>
                            )) : <span className="text-[9px] text-white/20 italic">Carregando validades...</span>}
                          </div>
                        </div>
                      </div>
                    </div>

              </div>

              <div className="space-y-4 p-5 bg-primary/5 rounded-2xl border border-primary/10 relative overflow-hidden group">
                 <div className="absolute -right-8 -top-8 w-24 h-24 bg-primary/10 rounded-full blur-3xl group-hover:scale-150 transition-all duration-700"></div>
                 <h4 className="text-xs font-black text-white flex items-center gap-2">
                    <Info className="w-4 h-4 text-primary" /> API Global de Bots
                 </h4>
                 <p className="text-white/50 text-[10px] leading-relaxed font-bold">
                    Ao fornecer o <code className="text-primary">target_username</code> (E-mail ou Usuário), os créditos (5 por key) serão descontados diretamente da conta desse usuário. 
                    Sem usuário, usa o <span className="text-primary underline">Super Admin</span>.
                 </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
