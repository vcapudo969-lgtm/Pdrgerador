import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ArrowLeftRight, 
  User, 
  Wallet, 
  AlertTriangle, 
  Loader2, 
  ShieldCheck,
  CheckCircle2,
  SendHorizontal
} from 'lucide-react';
import { toast } from 'sonner';

export default function TransferCreditsPage() {
  const { profile, refreshProfile } = useAuth();
  const [toUsername, setToUsername] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleTransfer = async () => {
    if (!profile) return;
    if (!toUsername || amount <= 0) {
      toast.error('Informe um usuário válido e um valor maior que zero');
      return;
    }

    if ((profile?.credits || 0) < amount) {
      toast.error('Saldo insuficiente');
      return;
    }

    setLoading(true);
    try {
      await api.transferCredits(profile.id, toUsername, amount);
      toast.success(`Transferência de ${amount} créditos realizada para ${toUsername}!`);
      refreshProfile();
      setToUsername('');
      setAmount(0);
      setShowConfirm(false);
    } catch (err: any) {
      toast.error(err.message || 'Erro ao realizar transferência');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="space-y-2">
        <h2 className="text-3xl font-black tracking-tight text-white">Transferir Créditos</h2>
        <p className="text-white/40 font-medium">Envie créditos instantaneamente para outros usuários da plataforma.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden h-fit">
          <CardHeader className="border-b border-white/5 pt-8 px-8">
            <CardTitle className="text-xl font-black text-white flex items-center gap-2">
              <SendHorizontal className="w-5 h-5 text-primary" /> Nova Transferência
            </CardTitle>
            <CardDescription className="text-white/40 font-bold">Preencha os dados do destinatário e o valor desejado.</CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label className="text-white/60 font-black text-xs uppercase tracking-widest ml-1 flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" /> Usuário de Destino
                </Label>
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-white/20 group-focus-within:text-primary transition-colors" />
                  <Input 
                    placeholder="Ex: Pedroxit" 
                    className="h-14 pl-12 bg-white/5 border-white/10 focus:border-primary/50 transition-all rounded-xl text-white font-bold"
                    value={toUsername}
                    onChange={(e) => setToUsername(e.target.value)}
                  />
                </div>
                <p className="text-[10px] text-white/20 uppercase tracking-widest font-black">Certifique-se do nome correto</p>
              </div>

              <div className="space-y-3">
                <Label className="text-white/60 font-black text-xs uppercase tracking-widest ml-1 flex items-center gap-2">
                  <Wallet className="w-4 h-4 text-primary" /> Valor do Envio
                </Label>
                <div className="relative group">
                  <Wallet className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-white/20 group-focus-within:text-primary transition-colors" />
                  <Input 
                    type="number" 
                    min="1" 
                    placeholder="0"
                    className="h-14 pl-12 bg-white/5 border-white/10 focus:border-primary/50 transition-all rounded-xl text-white text-xl font-black"
                    value={amount || ''}
                    onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
                  />
                </div>
                <p className="text-[10px] text-white/20 uppercase tracking-widest font-black">Saldo disponível: {profile?.credits}</p>
              </div>
            </div>

            <div className="bg-primary/5 border border-primary/10 rounded-2xl p-5 flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-xl">
                <AlertTriangle className="w-6 h-6 text-primary" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-black text-primary">Atenção!</p>
                <p className="text-xs text-white/40 font-bold leading-relaxed">Transferências são instantâneas e não podem ser desfeitas. Verifique cuidadosamente o username do destinatário.</p>
              </div>
            </div>

            <Button 
              className="w-full h-14 text-lg font-black rounded-xl shadow-xl shadow-primary/10 transition-all hover:scale-[1.01] active:scale-[0.99]" 
              onClick={() => setShowConfirm(true)}
              disabled={!toUsername || amount <= 0 || loading || (profile?.credits || 0) < amount}
            >
              Confirmar Transferência
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
           <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
             <CardHeader>
               <CardDescription className="text-[10px] font-black uppercase tracking-widest text-white/30">Seu Saldo Disponível</CardDescription>
               <CardTitle className="text-3xl font-black text-white flex items-center gap-2">
                 $ {(profile?.credits || 0).toLocaleString('pt-BR')}
               </CardTitle>
             </CardHeader>
             <CardContent className="space-y-4 pt-4 border-t border-white/5">
                <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest text-white/40">
                  <span>Limite Diário</span>
                  <span className="text-primary font-black">Ilimitado</span>
                </div>
             </CardContent>
           </Card>

           <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden">
             <CardHeader className="pb-2 border-b border-white/5">
                <CardTitle className="text-[10px] font-black uppercase tracking-widest text-white/30">Segurança da Transação</CardTitle>
             </CardHeader>
             <CardContent className="p-6 space-y-4">
               <div className="flex items-center gap-3">
                 <div className="p-1.5 rounded-lg bg-green-500/10 text-green-500">
                    <CheckCircle2 className="w-4 h-4" />
                 </div>
                 <p className="text-xs text-white/50 font-black uppercase tracking-widest">Instantâneo</p>
               </div>
               <div className="flex items-center gap-3">
                 <div className="p-1.5 rounded-lg bg-green-500/10 text-green-500">
                    <CheckCircle2 className="w-4 h-4" />
                 </div>
                 <p className="text-xs text-white/50 font-black uppercase tracking-widest">Seguro</p>
               </div>
               <div className="flex items-center gap-3">
                 <div className="p-1.5 rounded-lg bg-green-500/10 text-green-500">
                    <CheckCircle2 className="w-4 h-4" />
                 </div>
                 <p className="text-xs text-white/50 font-black uppercase tracking-widest">Sem Taxas</p>
               </div>
             </CardContent>
           </Card>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
          <Card className="w-full max-w-md shadow-2xl border-white/10 bg-black rounded-3xl overflow-hidden animate-in zoom-in duration-300">
            <CardHeader className="text-center pt-10 space-y-4">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary shadow-xl shadow-primary/5">
                <ShieldCheck className="w-10 h-10" />
              </div>
              <div className="space-y-1">
                <CardTitle className="text-2xl font-black text-white">Confirmar Envio</CardTitle>
                <CardDescription className="text-white/40 font-bold">Confirme os dados da transferência abaixo.</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6 p-10 pt-6">
              <div className="bg-white/5 rounded-2xl p-6 space-y-4 border border-white/5">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/30">Destinatário:</span>
                  <span className="text-sm font-black text-white">{toUsername}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/30">Valor Total:</span>
                  <span className="text-xl font-black text-primary">$ {amount}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="h-14 border-white/10 font-black rounded-xl hover:bg-white/5 text-white/60" onClick={() => setShowConfirm(false)}>Cancelar</Button>
                <Button className="h-14 font-black rounded-xl shadow-xl shadow-primary/10" onClick={handleTransfer} disabled={loading}>
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Confirmar Envio'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
