import React, { useEffect, useState } from 'react';
import { api } from '@/db/api';
import { LoginVersion, ValidityOption } from '../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Code, 
  ShieldCheck, 
  Terminal, 
  Copy, 
  CheckCircle2, 
  Globe,
  ExternalLink,
  Info,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

import { Badge } from '@/components/ui/badge';

export default function APIDocs() {
  const [versions, setVersions] = useState<LoginVersion[]>([]);
  const [validityOptions, setValidityOptions] = useState<ValidityOption[]>([]);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [versionsData, validityOptionsData] = await Promise.all([
          api.getLoginVersions(),
          api.getValidityOptions()
        ]);
        setVersions(versionsData || []);
        setValidityOptions(validityOptionsData || []);
      } catch (error) {
        console.error('Error fetching API docs options:', error);
      }
    };
    fetchData();
  }, []);

  const botApiEndpoint = `https://afquvklzmaanwnxcaqip.supabase.co/functions/v1/bot-api`;
  const externalGenerateEndpoint = `https://afquvklzmaanwnxcaqip.supabase.co/functions/v1/generate-bot-key-external`;
  
  const externalGenerateExample = `curl -X POST ${externalGenerateEndpoint} \\
  -H "Content-Type: application/json" \\
  -d '{
    "bot_name": "NOME-DO-BOT",
    "token": "JACINTOPINTOEREBOLO",
    "target_username": "LOGIN-OU-EMAIL-DO-CLIENTE",
    "version_name": "Lite",
    "validity_hours": 24,
    "devices": 1
  }'`;

  const generateExample = `curl -X POST ${botApiEndpoint}/generate \\
  -H "Authorization: Bearer SEU_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "prefix": "BOT",
    "version_id": "ID_DA_VERSAO",
    "validity_hours": 24,
    "credit_cost": 5,
    "quantity": 1,
    "devices": 1
  }'`;

  const validateExample = `curl -X POST ${botApiEndpoint}/validate \\
  -H "Authorization: Bearer SEU_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"key": "CÓDIGO-DA-KEY"}'`;

  const botCheckExample = `curl -X POST ${botApiEndpoint}/bot-check \\
  -H "Authorization: Bearer SEU_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"key": "CÓDIGO-DA-KEY"}'`;

  const manageKeyExample = `curl -X POST ${botApiEndpoint}/manage \\
  -H "Authorization: Bearer SEU_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "key": "CÓDIGO-DA-KEY",
    "action": "reset"
  }'`;

  const nodeManageExample = `const axios = require('axios');

async function manageKey(key, action) {
  try {
    const response = await axios.post('${botApiEndpoint}/manage', {
      key: key,
      action: action, // 'pause', 'resume', 'reset', 'ban'
      token: 'JACINTOPINTOEREBOLO' // Master Token Universal
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log(response.data.message);
  } catch (error) {
    console.error('Erro:', error.response?.data?.error || error.message);
  }
}

// Exemplo: manageKey('XYZ-12345', 'ban');`;

  const nodeGenerateExample = `const axios = require('axios');

async function generateKey(targetUser) {
  try {
    const response = await axios.post('${botApiEndpoint}/generate', {
      bot_name: 'MEU-BOT',
      target_username: targetUser, // Email ou Usuário do cliente
      version_name: 'Lite',
      validity_hours: 24,
      devices: 1,
      token: 'JACINTOPINTOEREBOLO'
    }, {
      headers: { 'Content-Type': 'application/json' }
    });

    if (response.data.success) {
      console.log('Key Gerada:', response.data.data.key_value);
    }
  } catch (error) {
    console.error('Erro:', error.response?.data?.error || error.message);
  }
}

// Exemplo: generateKey('cliente@email.com');`;

  const getVersionsExample = `curl -X GET ${botApiEndpoint}/versions \\
  -H "Authorization: Bearer SEU_API_KEY"`;

  const getValidityExample = `curl -X GET ${botApiEndpoint}/validity \\
  -H "Authorization: Bearer SEU_API_KEY"`;

  const copyToClipboard = (text: string, message: string) => {
    navigator.clipboard.writeText(text);
    toast.success(message);
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="space-y-2">
        <h2 className="text-3xl font-black tracking-tight text-white">Documentação <span className="text-primary">API</span></h2>
        <p className="text-white/40 font-medium">Instruções para integrar a validação de keys em seu software ou jogo.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Explanation */}
        <div className="lg:col-span-2 space-y-8">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden">
            <CardHeader className="bg-primary/5 border-b border-white/5">
              <CardTitle className="text-xl font-black text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-primary" /> API Externa (Geração Simplificada)
              </CardTitle>
              <CardDescription className="text-white/40 font-bold">API Global: Gera chaves de 24 horas para qualquer usuário informando seu login.</CardDescription>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Globe className="w-4 h-4 text-primary" /> Endpoint
                </h4>
                <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 group">
                  <Badge className="bg-green-500/20 text-green-500 border-none font-black text-[10px] uppercase px-3">POST</Badge>
                  <code className="text-primary font-mono text-sm break-all">{externalGenerateEndpoint}</code>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="ml-auto hover:bg-white/10"
                    onClick={() => copyToClipboard(externalGenerateEndpoint, 'URL da API externa copiada!')}
                  >
                    <Copy className="w-4 h-4 text-white/40" />
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-primary" /> Exemplo de Uso (Node.js/cURL)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-sm text-white/80 leading-relaxed">
                    {externalGenerateExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(externalGenerateExample, 'Exemplo externo copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
              <div className="space-y-4 p-5 bg-primary/5 rounded-2xl border border-primary/10">
                <h4 className="text-sm font-black text-white flex items-center gap-2">
                  <Info className="w-4 h-4 text-primary" /> Fluxo Interativo para Bots
                </h4>
                <p className="text-white/50 text-xs leading-relaxed font-bold">
                  Para implementar um fluxo onde o bot pergunta a versão e validade:<br /><br />
                  1. O bot deve fazer um <code className="text-primary">GET {externalGenerateEndpoint}</code> para obter as opções disponíveis.<br />
                  2. Apresente as opções ao usuário e capture as escolhas.<br />
                  3. Envie as escolhas no <code className="text-primary">POST</code> usando <code className="text-primary">version_name</code> e <code className="text-primary">validity_hours</code>.
                </p>

                <div className="pt-4 border-t border-primary/10 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <p className="text-[10px] font-black text-primary uppercase tracking-widest">Versões Ativas (version_name)</p>
                        <div className="flex flex-wrap gap-2">
                            {versions.length > 0 ? versions.map(v => (
                                <Badge key={v.id} variant="outline" className="bg-primary/10 border-primary/20 text-primary text-[10px] h-6 px-3 font-black uppercase tracking-widest">{v.name}</Badge>
                            )) : <span className="text-[10px] text-white/30 italic">Nenhuma versão configurada</span>}
                        </div>
                    </div>
                    <div className="space-y-2">
                        <p className="text-[10px] font-black text-primary uppercase tracking-widest">Validades Ativas (validity_hours)</p>
                        <div className="flex flex-wrap gap-2">
                            {validityOptions.length > 0 ? validityOptions.map(v => (
                                <Badge key={v.id} variant="outline" className="bg-primary/10 border-primary/20 text-primary text-[10px] h-6 px-3 font-black uppercase tracking-widest">{v.hours}H ({v.label})</Badge>
                            )) : <span className="text-[10px] text-white/30 italic">Nenhuma validade configurada</span>}
                        </div>
                    </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Code className="w-4 h-4 text-primary" /> Integração Node.js (Geração)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-xs text-white/80 leading-relaxed">
                    {nodeGenerateExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(nodeGenerateExample, 'Exemplo Node.js copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
              </div>

              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden">
            <CardHeader className="bg-primary/5 border-b border-white/5">
              <CardTitle className="text-xl font-black text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-primary" /> API para Bot (Geração)
              </CardTitle>
              <CardDescription className="text-white/40 font-bold">Como seu bot pode gerar keys automaticamente.</CardDescription>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Globe className="w-4 h-4 text-primary" /> Endpoint de Geração
                </h4>
                <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 group">
                  <Badge className="bg-green-500/20 text-green-500 border-none font-black text-[10px] uppercase px-3">POST</Badge>
                  <code className="text-primary font-mono text-sm break-all">{botApiEndpoint}/generate</code>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="ml-auto hover:bg-white/10"
                    onClick={() => copyToClipboard(`${botApiEndpoint}/generate`, 'URL da API de geração copiada!')}
                  >
                    <Copy className="w-4 h-4 text-white/40" />
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-primary" /> Exemplo de Geração (cURL)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-sm text-white/80 leading-relaxed">
                    {generateExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(generateExample, 'Exemplo de geração copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-primary" /> Validação para Bot
                </h4>
                <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 group">
                  <Badge className="bg-green-500/20 text-green-500 border-none font-black text-[10px] uppercase px-3">POST</Badge>
                  <code className="text-primary font-mono text-sm break-all">{botApiEndpoint}/validate</code>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="ml-auto hover:bg-white/10"
                    onClick={() => copyToClipboard(`${botApiEndpoint}/validate`, 'URL da API de validação copiada!')}
                  >
                    <Copy className="w-4 h-4 text-white/40" />
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-primary" /> Exemplo de Validação (cURL)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-sm text-white/80 leading-relaxed">
                    {validateExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(validateExample, 'Exemplo de validação copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-primary" /> Status para Bots (Mensagens Prontas)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-sm text-white/80 leading-relaxed">
                    {botCheckExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(botCheckExample, 'Exemplo de status de bot copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
                <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">Retorna uma mensagem formatada em Português pronta para o bot exibir.</p>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-primary" /> Gerenciamento via Bot
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-sm text-white/80 leading-relaxed">
                    {manageKeyExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(manageKeyExample, 'Exemplo de gerenciamento copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <Badge variant="outline" className="text-[9px] font-black uppercase tracking-widest h-6 justify-center">pause</Badge>
                  <Badge variant="outline" className="text-[9px] font-black uppercase tracking-widest h-6 justify-center">resume</Badge>
                  <Badge variant="outline" className="text-[9px] font-black uppercase tracking-widest h-6 justify-center">reset</Badge>
                  <Badge variant="outline" className="text-[9px] font-black uppercase tracking-widest h-6 justify-center">ban</Badge>
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Code className="w-4 h-4 text-primary" /> Integração Node.js (Management)
                </h4>
                <div className="relative group">
                  <pre className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5 overflow-x-auto font-mono text-xs text-white/80 leading-relaxed">
                    {nodeManageExample}
                  </pre>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="absolute top-4 right-4 bg-white/5 border-white/10 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest"
                    onClick={() => copyToClipboard(nodeManageExample, 'Exemplo Node.js copiado!')}
                  >
                    <Copy className="w-3 h-3 mr-2" /> Copiar
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-primary" /> Obter Versões e Validade
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative group">
                    <pre className="bg-[#0a0a0a] p-4 rounded-2xl border border-white/5 overflow-x-auto font-mono text-[10px] text-white/80">
                      {getVersionsExample}
                    </pre>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-2 right-2 hover:bg-white/10"
                      onClick={() => copyToClipboard(getVersionsExample, 'CURL de versões copiado!')}
                    >
                      <Copy className="w-3 h-3 text-white/40" />
                    </Button>
                  </div>
                  <div className="relative group">
                    <pre className="bg-[#0a0a0a] p-4 rounded-2xl border border-white/5 overflow-x-auto font-mono text-[10px] text-white/80">
                      {getValidityExample}
                    </pre>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-2 right-2 hover:bg-white/10"
                      onClick={() => copyToClipboard(getValidityExample, 'CURL de validade copiado!')}
                    >
                      <Copy className="w-3 h-3 text-white/40" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-8 space-y-6">
            <h4 className="text-xl font-black text-white flex items-center gap-2">
              <Info className="w-5 h-5 text-primary" /> Parâmetros de Resposta (Geração)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 p-4 bg-white/5 rounded-xl border border-white/5">
                <p className="text-sm font-black text-primary uppercase tracking-widest">success</p>
                <p className="text-xs text-white/40 leading-relaxed">Booleano indicando se a geração foi bem sucedida.</p>
              </div>
              <div className="space-y-2 p-4 bg-white/5 rounded-xl border border-white/5">
                <p className="text-sm font-black text-primary uppercase tracking-widest">keys</p>
                <p className="text-xs text-white/40 leading-relaxed">Array contendo os objetos das keys recém geradas.</p>
              </div>
              <div className="space-y-2 p-4 bg-white/5 rounded-xl border border-white/5">
                <p className="text-sm font-black text-primary uppercase tracking-widest">error</p>
                <p className="text-xs text-white/40 leading-relaxed">Mensagem de erro caso algo dê errado (ex: créditos insuficientes).</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Column - Quick Reference */}
        <div className="space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-8 space-y-4">
            <h4 className="text-lg font-black text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" /> Opções do Gerador
            </h4>
            <div className="space-y-6 pt-4">
              <div className="space-y-3">
                <p className="text-[10px] font-black text-primary uppercase tracking-widest">Versões (version_name):</p>
                <div className="flex flex-wrap gap-2">
                  {versions.map(v => (
                    <Badge key={v.id} variant="outline" className="bg-primary/5 border-primary/20 text-primary text-[9px] h-5 px-2 font-black uppercase tracking-widest">{v.name}</Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-[10px] font-black text-primary uppercase tracking-widest">Validades (validity_hours):</p>
                <div className="flex flex-wrap gap-2">
                  {validityOptions.map(v => (
                    <Badge key={v.id} variant="outline" className="bg-primary/5 border-primary/20 text-primary text-[9px] h-5 px-2 font-black uppercase tracking-widest">{v.hours}H</Badge>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          <Card className="border-white/5 bg-primary/10 backdrop-blur-xl p-8 space-y-4">
            <h4 className="text-lg font-black text-white flex items-center gap-2">
              <Code className="w-5 h-5 text-primary" /> API Key
            </h4>
            <p className="text-sm text-white/60 leading-relaxed font-medium">Use sua API Key sk_... no cabeçalho Authorization como Bearer token.</p>
            <div className="space-y-3 pt-4">
              <div className="flex items-center gap-3 text-xs font-bold text-white/40">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span>Gere sua key em "API Keys" no perfil</span>
              </div>
              <div className="flex items-center gap-3 text-xs font-bold text-white/40">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span>Mantenha sua API Key em segredo</span>
              </div>
            </div>
          </Card>

          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-8 space-y-4 text-center">
            <h4 className="text-sm font-black text-white/40 uppercase tracking-widest">Dúvidas na Integração?</h4>
            <p className="text-xs text-white/30 font-bold">Entre em contato com o suporte para assistência técnica personalizada.</p>
            <Button variant="ghost" className="w-full text-xs font-black uppercase tracking-widest text-primary hover:bg-primary/10">
              Contatar Suporte
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
