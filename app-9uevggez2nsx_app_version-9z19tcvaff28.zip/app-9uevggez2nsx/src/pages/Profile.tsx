import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  User, 
  Mail, 
  Lock, 
  ShieldCheck, 
  Smartphone, 
  Save, 
  Camera,
  Loader2,
  Calendar,
  BadgeCheck,
  Code,
  Trash2,
  PlusCircle,
  Copy
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { APIKey } from '../app_types';

function APIKeySection() {
  const { profile } = useAuth();
  const [keys, setKeys] = React.useState<APIKey[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [creating, setCreating] = React.useState(false);
  const [label, setLabel] = React.useState('');

  const fetchKeys = async () => {
    if (!profile) return;
    try {
      const data = await api.getMyAPIKeys(profile.id);
      setKeys(data);
    } catch (err) {
      toast.error('Erro ao carregar API Keys');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchKeys();
  }, [profile]);

  const handleGenerate = async () => {
    if (!profile || !label) {
      toast.error('Informe um rótulo para a API Key');
      return;
    }
    setCreating(true);
    try {
      await api.generateAPIKey(profile.id, label);
      toast.success('API Key gerada com sucesso!');
      setLabel('');
      fetchKeys();
    } catch (err) {
      toast.error('Erro ao gerar API Key');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAPIKey(id);
      toast.success('API Key removida');
      fetchKeys();
    } catch (err) {
      toast.error('Erro ao remover API Key');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('API Key copiada para a área de transferência!');
  };

  return (
    <Card className="border-border/40 bg-card/40 backdrop-blur-sm">
      <CardHeader className="border-b border-border/20">
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <Code className="w-5 h-5 text-primary" /> API Keys para Bots
        </CardTitle>
        <CardDescription>
          Gere chaves de API para integrar seus bots e sistemas externos.
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-8 space-y-6">
        <div className="flex gap-4">
          <div className="flex-1">
            <Label className="sr-only">Rótulo da API Key</Label>
            <Input 
              placeholder="Ex: Meu Bot Discord" 
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              className="h-12 bg-background/50 border-border/40"
            />
          </div>
          <Button onClick={handleGenerate} disabled={creating} className="h-12 px-6 gap-2">
            {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlusCircle className="w-4 h-4" />}
            Gerar Nova Key
          </Button>
        </div>

        <div className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary/20" />
            </div>
          ) : keys.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground text-sm font-medium">Nenhuma API Key gerada ainda.</p>
          ) : (
            <div className="rounded-xl border border-border/20 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border/20">
                  <tr>
                    <th className="px-4 py-3 text-left font-bold uppercase tracking-widest text-[10px] text-muted-foreground">Rótulo</th>
                    <th className="px-4 py-3 text-left font-bold uppercase tracking-widest text-[10px] text-muted-foreground">Key</th>
                    <th className="px-4 py-3 text-right font-bold uppercase tracking-widest text-[10px] text-muted-foreground">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/20">
                  {keys.map((key) => (
                    <tr key={key.id} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-4 font-bold">{key.label}</td>
                      <td className="px-4 py-4">
                        <code className="bg-background/80 px-2 py-1 rounded text-primary font-mono text-xs">
                          {key.key_value.substring(0, 10)}...{key.key_value.substring(key.key_value.length - 4)}
                        </code>
                      </td>
                      <td className="px-4 py-4 text-right space-x-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => copyToClipboard(key.key_value)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => handleDelete(key.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const [username, setUsername] = useState(profile?.username || '');
  const [email, setEmail] = useState(profile?.email || '');
  const [loading, setLoading] = useState(false);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    
    setLoading(true);
    try {
      await api.updateProfile(profile.id, { username, email });
      toast.success('Perfil atualizado com sucesso!');
      refreshProfile();
    } catch (err) {
      toast.error('Erro ao atualizar perfil');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-bold tracking-tight">Meu Perfil</h2>
        <p className="text-muted-foreground">Gerencie suas informações pessoais e segurança da conta.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Left Column: Avatar & Quick Info */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="border-border/40 bg-card/40 backdrop-blur-sm overflow-hidden border-b-4 border-b-primary shadow-xl">
            <CardHeader className="text-center pt-10 pb-6 relative">
              <div className="mx-auto w-32 h-32 rounded-full border-4 border-primary/20 p-1 relative group cursor-pointer overflow-hidden">
                <Avatar className="w-full h-full">
                   <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username}`} />
                   <AvatarFallback className="bg-primary/10 text-primary text-2xl font-black">
                     {profile?.username?.charAt(0).toUpperCase() || 'U'}
                   </AvatarFallback>
                </Avatar>
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                  <Camera className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="mt-4 space-y-1">
                <div className="flex items-center justify-center gap-2">
                  <h3 className="text-xl font-black">{profile?.username}</h3>
                  <BadgeCheck className="w-5 h-5 text-primary fill-primary/20" />
                </div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{profile?.role}</p>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 pt-4 border-t border-border/20">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground flex items-center gap-2"><Calendar className="w-4 h-4" /> Membro desde</span>
                <span className="font-bold">2026</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground flex items-center gap-2"><Smartphone className="w-4 h-4" /> Dispositivos</span>
                <span className="font-bold">2 Ativos</span>
              </div>
            </CardContent>
            <CardFooter className="bg-muted/30 pt-4 flex flex-col gap-2">
               <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-2/3 shadow-[0_0_10px_rgba(var(--primary),0.5)]"></div>
               </div>
               <p className="text-[10px] text-muted-foreground font-bold uppercase text-center w-full">Nível de Conta: Ouro</p>
            </CardFooter>
          </Card>

          <Card className="border-border/40 bg-card/40 backdrop-blur-sm border-l-4 border-l-orange-500">
             <CardContent className="p-4 flex items-center gap-4">
                <div className="p-2 bg-orange-500/10 rounded-lg">
                  <ShieldCheck className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <p className="text-sm font-bold">Autenticação 2FA</p>
                  <p className="text-[10px] text-muted-foreground">Proteja sua conta agora</p>
                </div>
                <Button variant="ghost" size="sm" className="ml-auto text-orange-500 hover:bg-orange-500/10">Ativar</Button>
             </CardContent>
          </Card>
        </div>

        {/* Right Column: Edit Form */}
        <div className="lg:col-span-3 space-y-8">
          <Card className="border-border/40 bg-card/40 backdrop-blur-sm">
            <CardHeader className="border-b border-border/20">
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <User className="w-5 h-5 text-primary" /> Informações Básicas
              </CardTitle>
            </CardHeader>
            <form onSubmit={handleUpdate}>
              <CardContent className="pt-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="username" className="font-bold">Nome de Usuário</Label>
                    <div className="relative">
                      <Input 
                        id="username" 
                        value={username} 
                        onChange={(e) => setUsername(e.target.value)}
                        className="h-12 bg-background/50 border-border/40 pl-10 font-bold"
                      />
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="font-bold">E-mail</Label>
                    <div className="relative">
                      <Input 
                        id="email" 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)}
                        className="h-12 bg-background/50 border-border/40 pl-10 font-bold"
                      />
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                   <Button type="submit" className="h-12 px-8 font-bold gap-2 shadow-lg shadow-primary/20" disabled={loading}>
                     {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                     Salvar Alterações
                   </Button>
                </div>
              </CardContent>
            </form>
          </Card>

          <Card className="border-border/40 bg-card/40 backdrop-blur-sm">
            <CardHeader className="border-b border-border/20">
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <Lock className="w-5 h-5 text-primary" /> Alterar Senha
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label className="font-bold">Senha Atual</Label>
                  <Input type="password" placeholder="••••••••" className="h-12 bg-background/50 border-border/40" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">Nova Senha</Label>
                  <Input type="password" placeholder="••••••••" className="h-12 bg-background/50 border-border/40" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">Confirmar Nova Senha</Label>
                  <Input type="password" placeholder="••••••••" className="h-12 bg-background/50 border-border/40" />
                </div>
              </div>
              <div className="pt-4 flex justify-end">
                 <Button variant="outline" className="h-12 px-8 font-bold border-primary/20 text-primary hover:bg-primary/10 transition-all">
                   Redefinir Senha
                 </Button>
              </div>
            </CardContent>
          </Card>
          <APIKeySection />

        </div>
      </div>
    </div>
  );
}
