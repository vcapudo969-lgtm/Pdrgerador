import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { APIKey } from '../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Code, 
  PlusCircle, 
  Trash2, 
  Copy, 
  Loader2, 
  Key,
  Terminal,
  Info
} from 'lucide-react';
import { toast } from 'sonner';

export default function APIKeysPage() {
  const { profile } = useAuth();
  const [keys, setKeys] = useState<APIKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [label, setLabel] = useState('');

  const fetchKeys = async () => {
    if (!profile) return;
    try {
      const data = await api.getMyAPIKeys(profile.id);
      setKeys(data);
    } catch (err) {
      toast.error('Erro ao carregar API Keys');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKeys();
  }, [profile]);

  const handleGenerate = async () => {
    if (!profile || !label) {
      toast.error('Informe um rótulo para a API Key');
      return;
    }
    setCreating(true);
    try {
      await api.generateAPIKey(profile.id, label);
      toast.success('API Key gerada com sucesso!');
      setLabel('');
      fetchKeys();
    } catch (err) {
      toast.error('Erro ao gerar API Key');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAPIKey(id);
      toast.success('API Key removida');
      fetchKeys();
    } catch (err) {
      toast.error('Erro ao remover API Key');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('API Key copiada!');
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="space-y-1">
        <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
          <Terminal className="w-8 h-8 text-primary" /> Minhas <span className="text-primary">API Keys</span>
        </h2>
        <p className="text-white/40 font-medium text-sm">Gerencie suas chaves para integrações de bots externos.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
            <CardHeader className="border-b border-white/5">
              <CardTitle className="text-lg font-bold">API Keys Ativas</CardTitle>
              <CardDescription className="text-white/40">Use estas chaves para autenticar seu bot na API privada.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="flex justify-center p-20">
                  <Loader2 className="w-10 h-10 animate-spin text-primary/20" />
                </div>
              ) : keys.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-20 text-center space-y-3">
                  <Key className="w-10 h-10 text-white/10" />
                  <p className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Nenhuma API Key gerada</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {keys.map((key) => (
                    <div key={key.id} className="p-6 flex items-center justify-between group hover:bg-white/5 transition-all">
                      <div className="space-y-1.5">
                        <p className="font-bold text-white group-hover:text-primary transition-colors">{key.label}</p>
                        <code className="text-[11px] font-mono text-white/30 bg-white/5 px-2 py-1 rounded-md">
                          {key.key_value.substring(0, 10)}...{key.key_value.substring(key.key_value.length - 4)}
                        </code>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-9 w-9 text-white/20 hover:text-primary hover:bg-primary/10 rounded-xl transition-all"
                          onClick={() => copyToClipboard(key.key_value)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-9 w-9 text-white/20 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                          onClick={() => handleDelete(key.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl border-t-4 border-t-primary overflow-hidden">
            <CardHeader>
              <CardTitle className="text-lg font-bold">Gerar Nova Key</CardTitle>
              <CardDescription className="text-white/40 text-xs">Atribua um nome para identificar o sistema.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Nome do Sistema/Bot</Label>
                <Input 
                  placeholder="Ex: Discord Bot Oficial" 
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  className="h-12 bg-white/5 border-white/10 rounded-xl font-bold"
                />
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={creating || !label} 
                className="w-full h-12 rounded-xl font-black uppercase tracking-widest shadow-xl shadow-primary/10 text-xs"
              >
                {creating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <PlusCircle className="w-4 h-4 mr-2" />}
                Gerar Key
              </Button>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-primary/5 p-6 space-y-3 rounded-2xl border border-primary/10">
            <div className="flex items-center gap-2 text-primary font-bold text-sm">
              <Info className="w-4 h-4" /> Dica de Segurança
            </div>
            <p className="text-[10px] text-white/40 leading-relaxed font-bold uppercase tracking-wider">
              Nunca compartilhe sua API Key com ninguém. Ela permite gerar keys e acessar dados da sua conta.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
