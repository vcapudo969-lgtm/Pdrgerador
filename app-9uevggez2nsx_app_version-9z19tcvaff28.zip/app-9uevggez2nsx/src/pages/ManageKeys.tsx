import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { GeneratedKey } from '../app_types';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { 
  MoreVertical, 
  Copy, 
  Trash, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Search,
  Filter,
  Download,
  Pause,
  Play,
  RotateCcw
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function ManageKeysPage() {
  const { profile } = useAuth();
  const [keys, setKeys] = useState<GeneratedKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchKeys = () => {
    if (profile) {
      api.getMyKeys(profile.id).then(data => {
        setKeys(data);
        setLoading(false);
      });
    }
  };

  useEffect(() => {
    fetchKeys();
  }, [profile]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Key copiada para a área de transferência!');
  };

  const handlePause = async (keyId: string, currentStatus: string) => {
    try {
      await api.pauseKey(keyId, currentStatus);
      toast.success(`Key ${currentStatus === 'active' ? 'pausada' : 'ativada'} com sucesso!`);
      fetchKeys();
    } catch (err: any) {
      toast.error('Erro ao alternar status da key');
    }
  };

  const handleReset = async (keyId: string) => {
    try {
      await api.resetKey(keyId);
      toast.success('Key resetada com sucesso!');
      fetchKeys();
    } catch (err: any) {
      toast.error('Erro ao resetar key');
    }
  };

  const filteredKeys = keys.filter(k => 
    k.key_value.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight text-white">Gerenciar Keys</h2>
          <p className="text-white/40 font-medium text-sm">Visualize e gerencie todas as suas keys geradas.</p>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline" size="sm" className="gap-2 bg-white/5 border-white/10 hover:bg-white/10 rounded-xl h-10 px-4 font-bold text-xs">
             <Download className="w-4 h-4" /> Exportar
           </Button>
        </div>
      </div>

      <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
        <CardHeader className="border-b border-white/5 space-y-4 p-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-80 group">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-white/30 group-focus-within:text-primary transition-colors" />
              <Input 
                placeholder="Pesquisar por key..." 
                className="pl-9 h-10 bg-white/5 border-white/10 focus:border-primary/50 transition-all rounded-xl text-white text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Button variant="ghost" size="sm" className="gap-2 border border-white/10 hover:bg-white/5 text-white/60 font-bold rounded-xl h-10 px-4 text-xs">
                <Filter className="w-3.5 h-3.5" /> Filtros
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="w-[250px] font-bold text-[9px] uppercase tracking-widest text-white/40">Key</TableHead>
                  <TableHead className="font-bold text-[9px] uppercase tracking-widest text-white/40">Versão</TableHead>
                  <TableHead className="font-bold text-[9px] uppercase tracking-widest text-white/40">Validade</TableHead>
                  <TableHead className="font-bold text-[9px] uppercase tracking-widest text-white/40">Dispositivos</TableHead>
                  <TableHead className="font-bold text-[9px] uppercase tracking-widest text-white/40 text-center">Status</TableHead>
                  <TableHead className="w-[80px] text-right font-bold text-[9px] uppercase tracking-widest text-white/40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  [1, 2, 3, 4, 5].map(i => (
                    <TableRow key={i} className="border-white/5">
                      <TableCell colSpan={6} className="h-14 animate-pulse bg-white/5"></TableCell>
                    </TableRow>
                  ))
                ) : filteredKeys.length > 0 ? (
                  filteredKeys.map((key) => (
                    <TableRow key={key.id} className="border-white/5 group hover:bg-white/5 transition-colors">
                      <TableCell className="font-mono text-xs font-bold tracking-wider text-white group-hover:text-primary transition-colors">
                        {key.key_value}
                      </TableCell>
                      <TableCell className="text-xs font-bold text-white/70">
                        {key.version?.name || 'Standard'}
                      </TableCell>
                      <TableCell className="text-xs">
                        <div className="flex items-center gap-1.5 text-white/50 font-bold">
                          <Clock className="w-3 h-3 text-primary" />
                          {key.validity_hours}h
                        </div>
                      </TableCell>
                      <TableCell className="text-xs text-center font-bold text-white/70">
                        {key.devices_allowed}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge 
                          className={cn(
                            "rounded-lg font-bold text-[9px] uppercase tracking-widest border-none",
                            key.status === 'active' ? 'bg-primary/10 text-primary' : 'bg-white/10 text-white/40'
                          )}
                        >
                          {key.status === 'active' ? 'Ativa' : key.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10 text-white/40 hover:text-white rounded-xl">
                              <MoreVertical className="h-3.5 h-3.5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-40 bg-black border-white/10 text-white rounded-xl">
                            <DropdownMenuItem onClick={() => copyToClipboard(key.key_value)} className="gap-2 cursor-pointer focus:bg-primary focus:text-primary-foreground font-bold text-xs">
                              <Copy className="h-3.5 h-3.5" /> Copiar Key
                            </DropdownMenuItem>
                            <DropdownMenuSeparator className="bg-white/5" />
                            <DropdownMenuItem 
                              onClick={() => handlePause(key.id, key.status)} 
                              className="gap-2 cursor-pointer focus:bg-orange-500 focus:text-white font-bold text-xs"
                            >
                              {key.status === 'active' ? (
                                <><Pause className="h-3.5 h-3.5" /> Pausar Key</>
                              ) : (
                                <><Play className="h-3.5 h-3.5" /> Ativar Key</>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleReset(key.id)} 
                              className="gap-2 cursor-pointer focus:bg-blue-500 focus:text-white font-bold text-xs"
                            >
                              <RotateCcw className="h-3.5 h-3.5" /> Resetar Key
                            </DropdownMenuItem>
                            <DropdownMenuSeparator className="bg-white/5" />
                            <DropdownMenuItem className="gap-2 text-red-500 focus:text-white focus:bg-red-500 cursor-pointer font-bold text-xs">
                              <Trash className="h-3.5 h-3.5" /> Excluir Key
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-40 text-center text-white/20 font-bold uppercase tracking-widest text-[10px]">
                      Nenhuma key encontrada.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
