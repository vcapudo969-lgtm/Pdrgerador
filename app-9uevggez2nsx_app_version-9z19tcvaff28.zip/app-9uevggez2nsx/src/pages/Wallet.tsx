import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Wallet, 
  TrendingUp, 
  ArrowLeftRight, 
  History, 
  PlusCircle, 
  BadgeCheck, 
  Zap, 
  Smartphone, 
  Globe, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck, 
  Info,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

const packages = [
  { id: 1, name: "Bronze", credits: 50, price: 25, popular: false, bonus: 0 },
  { id: 2, name: "Prata", credits: 150, price: 65, popular: true, bonus: 10 },
  { id: 3, name: "Ouro", credits: 500, price: 180, popular: false, bonus: 50 },
  { id: 4, name: "Diamante", credits: 1500, price: 450, popular: false, bonus: 200 }
];

export default function WalletPage() {
  const { profile } = useAuth();
  
  const handleBuy = (pkgName: string) => {
    toast.success(`Interesse no pacote ${pkgName} registrado. Entre em contato com o administrador para finalizar o pagamento.`);
    // Simular abertura de WhatsApp
    window.open(`https://wa.me/5500000000000?text=Olá, tenho interesse no pacote ${pkgName} de créditos para o PDR Gerador.`, '_blank');
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="space-y-1">
        <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
          <Wallet className="w-8 h-8 text-primary" /> Minha <span className="text-primary">Carteira</span>
        </h2>
        <p className="text-white/40 font-medium text-sm">Gerencie seus créditos, compre pacotes e veja seu histórico.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Balance Card */}
        <Card className="border-white/5 bg-black/40 backdrop-blur-xl relative overflow-hidden group border-l-4 border-l-primary shadow-2xl">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-all group-hover:scale-125 duration-700">
            <Wallet className="w-20 h-20 text-primary" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-black uppercase tracking-widest text-white/30">Saldo Atual</CardDescription>
            <CardTitle className="text-3xl font-black text-white flex items-center gap-2">
              $ {profile?.credits?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 flex items-center gap-4">
            <Link to="/transfer-credits" className="flex-1">
                <Button variant="outline" className="w-full h-10 border-white/10 hover:bg-white/5 gap-2 rounded-xl font-bold text-xs uppercase tracking-widest">
                    <ArrowLeftRight className="w-3.5 h-3.5" /> Transferir
                </Button>
            </Link>
            <Button className="flex-1 h-10 gap-2 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg shadow-primary/20">
                <PlusCircle className="w-3.5 h-3.5" /> Adicionar
            </Button>
          </CardContent>
        </Card>

        {/* Stats Card */}
        <Card className="border-white/5 bg-black/40 backdrop-blur-xl relative overflow-hidden group border-l-4 border-l-orange-500 shadow-2xl">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-all group-hover:scale-125 duration-700">
            <TrendingUp className="w-20 h-20 text-orange-500" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-black uppercase tracking-widest text-white/30">Total Gasto</CardDescription>
            <CardTitle className="text-3xl font-black text-white">$ 1.250,00</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
             <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-orange-500 bg-orange-500/10 px-3 py-1.5 rounded-lg w-fit">
                <ArrowUpRight className="w-3.5 h-3.5" /> +15% este mês
             </div>
          </CardContent>
        </Card>

        {/* Level Card */}
        <Card className="border-white/5 bg-black/40 backdrop-blur-xl relative overflow-hidden group border-l-4 border-l-blue-500 shadow-2xl">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-all group-hover:scale-125 duration-700">
            <BadgeCheck className="w-20 h-20 text-blue-500" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-black uppercase tracking-widest text-white/30">Nível do Perfil</CardDescription>
            <CardTitle className="text-3xl font-black text-white flex items-center gap-2">
              VIP <span className="text-blue-500">PLATINA</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
             <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden mb-2">
                <div className="h-full bg-blue-500 w-3/4"></div>
             </div>
             <p className="text-[9px] font-black uppercase tracking-[0.2em] text-white/20">Progresso para o nível DIAMANTE (75%)</p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
           <div className="space-y-1">
             <h3 className="text-xl font-black text-white flex items-center gap-2">
               <Zap className="w-5 h-5 text-primary" /> Comprar Pacotes de <span className="text-primary">Créditos</span>
             </h3>
             <p className="text-white/40 font-medium text-xs">Aumente sua produtividade com pacotes de créditos especiais.</p>
           </div>
           <div className="flex items-center gap-3 p-3 bg-primary/5 rounded-xl border border-primary/10 shadow-xl shadow-primary/5">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-white">Pagamento Seguro via PIX</p>
                <p className="text-[9px] text-white/40 font-bold leading-none">Confirmação automática imediata</p>
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {packages.map((pkg) => (
            <Card key={pkg.id} className={cn(
              "border-white/5 bg-black/40 backdrop-blur-xl group hover:border-primary/50 transition-all duration-500 flex flex-col relative",
              pkg.popular && "border-primary/30 ring-2 ring-primary/20 scale-105 z-10"
            )}>
              {pkg.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg shadow-primary/30">
                  Mais Popular
                </div>
              )}
              <CardHeader className="text-center p-8">
                <CardDescription className="text-[10px] font-black uppercase tracking-widest text-white/30">{pkg.name}</CardDescription>
                <CardTitle className="text-4xl font-black text-white my-2">{pkg.credits}</CardTitle>
                <CardDescription className="text-xs font-bold text-white/60">Créditos</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 px-8 pb-8 space-y-6">
                 <div className="space-y-3">
                    <div className="flex items-center gap-3 text-[10px] font-bold text-white/40">
                       <CheckCircle2 className="w-4 h-4 text-primary" />
                       <span>Geração de keys ilimitada</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-white/40">
                       <CheckCircle2 className="w-4 h-4 text-primary" />
                       <span>Acesso total à API</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-white/40">
                       <CheckCircle2 className="w-4 h-4 text-primary" />
                       <span className="text-primary">Bônus: {pkg.bonus} créditos extras</span>
                    </div>
                 </div>
                 
                 <div className="pt-6 border-t border-white/5">
                    <div className="flex items-baseline justify-center gap-1 mb-6">
                        <span className="text-sm font-bold text-white/30">R$</span>
                        <span className="text-3xl font-black text-white">{pkg.price}</span>
                        <span className="text-[10px] font-bold text-white/30 uppercase tracking-widest">/ único</span>
                    </div>
                    <Button 
                      className={cn(
                        "w-full h-12 rounded-xl font-black uppercase tracking-widest text-xs transition-all",
                        pkg.popular ? "bg-primary text-primary-foreground shadow-xl shadow-primary/20" : "bg-white/5 border border-white/10 text-white hover:bg-white/10"
                      )}
                      onClick={() => handleBuy(pkg.name)}
                    >
                      Comprar Agora
                    </Button>
                 </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Card className="border-white/5 bg-black/40 backdrop-blur-xl border-t-4 border-t-primary overflow-hidden shadow-2xl">
         <CardHeader className="p-8 border-b border-white/5 bg-primary/5">
            <div className="flex items-center justify-between">
                <div className="space-y-1">
                    <CardTitle className="text-lg font-black text-white flex items-center gap-2">
                        <History className="w-5 h-5 text-primary" /> Histórico de Transações Recentes
                    </CardTitle>
                    <CardDescription className="text-white/40 font-bold text-xs uppercase tracking-widest">Acompanhe suas movimentações financeiras no sistema.</CardDescription>
                </div>
                <Button variant="ghost" className="text-primary hover:bg-primary/10 font-black uppercase text-[10px] tracking-widest">Ver Completo</Button>
            </div>
         </CardHeader>
         <CardContent className="p-0">
             <div className="divide-y divide-white/5">
                {[
                  { id: 1, type: 'compra', amount: 150, date: 'Hoje, 14:30', status: 'concluido' },
                  { id: 2, type: 'gerar_key', amount: -5, date: 'Hoje, 12:15', status: 'concluido' },
                  { id: 3, type: 'transferencia', amount: -50, date: 'Ontem, 19:45', status: 'concluido' },
                  { id: 4, type: 'bonus', amount: 10, date: 'Ontem, 09:00', status: 'concluido' }
                ].map((tx) => (
                  <div key={tx.id} className="p-5 flex items-center justify-between group hover:bg-white/5 transition-all">
                    <div className="flex items-center gap-4">
                        <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center transition-all group-hover:scale-110",
                            tx.amount > 0 ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                        )}>
                            {tx.amount > 0 ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                        </div>
                        <div>
                            <p className="text-xs font-black text-white uppercase tracking-widest">{tx.type.replace('_', ' ')}</p>
                            <p className="text-[10px] text-white/30 font-bold uppercase flex items-center gap-1">
                                <Calendar className="w-2.5 h-2.5" /> {tx.date}
                            </p>
                        </div>
                    </div>
                    <div className="text-right space-y-1">
                        <p className={cn(
                            "text-lg font-black tracking-tight",
                            tx.amount > 0 ? "text-green-500" : "text-white"
                        )}>
                            {tx.amount > 0 ? '+' : ''}{tx.amount}
                        </p>
                        <Badge variant="outline" className="h-4 px-1.5 text-[8px] font-black uppercase tracking-tighter border-white/10 text-white/30 rounded-md">
                            Concluído
                        </Badge>
                    </div>
                  </div>
                ))}
             </div>
         </CardContent>
      </Card>
    </div>
  );
}
