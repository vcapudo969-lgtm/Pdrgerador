import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { GeneratedKey, Transaction } from '../app_types';
import { 
  Key, 
  Wallet, 
  History, 
  PlusCircle, 
  TrendingUp,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  ShieldCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';

export default function Dashboard() {
  const { profile } = useAuth();
  const [keys, setKeys] = useState<GeneratedKey[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [usageStats, setUsageStats] = useState<{ date: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      Promise.all([
        api.getMyKeys(profile.id, 5),
        api.getMyTransactions(profile.id),
        api.getUsageStats(profile.id)
      ]).then(([keysData, transData, statsData]) => {
        setKeys(keysData);
        setTransactions(transData.slice(0, 5));
        setUsageStats(statsData);
        setLoading(false);
      });
    }
  }, [profile]);

  if (loading) {
    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 bg-muted w-full rounded-xl" />)}
        </div>
        <Skeleton className="h-64 bg-muted w-full rounded-xl" />
      </div>
    );
  }

  const activeKeysCount = keys.filter(k => k.status === 'active').length;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Welcome Section */}
      <section className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-white">Bem-vindo, <span className="gradient-text">{profile?.username}</span>! 👋</h2>
        <p className="text-white/40 font-medium">Aqui está um resumo das suas atividades e saldo atual.</p>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden relative group">
          <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
            <Wallet className="w-12 h-12 text-primary" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-white/30">Saldo em Créditos</CardDescription>
            <CardTitle className="text-2xl font-bold text-white flex items-center gap-2">
              $ {profile?.credits?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-white/30 font-bold uppercase tracking-widest mt-2">Saldo em conta</div>
          </CardContent>
        </Card>

        <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden relative group">
          <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
            <Key className="w-12 h-12 text-primary" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-white/30">Keys Ativas</CardDescription>
            <CardTitle className="text-2xl font-bold text-white">{activeKeysCount}</CardTitle>
          </CardHeader>
          <CardContent>
            <Link to="/generate-keys">
              <Button variant="outline" size="sm" className="w-full mt-2 border-primary/20 hover:bg-primary/10 text-primary font-bold rounded-xl transition-all">
                Gerar Nova Key
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="border-white/5 bg-black/40 backdrop-blur-xl overflow-hidden relative group">
          <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
            <ShieldCheck className="w-12 h-12 text-primary" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest text-white/30">Status do Sistema</CardDescription>
            <CardTitle className="text-2xl font-bold text-green-500">Online</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-[10px] text-white/40 flex items-center gap-1 font-bold uppercase tracking-widest">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Operando normalmente
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Usage Chart */}
      <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
        <CardHeader>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <CardTitle className="text-base font-bold text-white">Uso nos Últimos 7 Dias</CardTitle>
          </div>
          <CardDescription className="text-white/40 font-medium text-xs">Quantidade de keys geradas por dia</CardDescription>
        </CardHeader>
        <CardContent className="h-[250px] w-full pt-4">
          <ChartContainer config={{ 
            count: { label: "Keys Geradas", color: "hsl(var(--primary))" } 
          }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usageStats} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 9, fontWeight: 'bold' }} 
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(val) => {
                    const d = new Date(val);
                    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
                  }}
                />
                <YAxis 
                  tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 9, fontWeight: 'bold' }} 
                  axisLine={false}
                  tickLine={false}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar 
                  dataKey="count" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]} 
                  barSize={24}
                />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Recent Keys */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-primary" /> Keys Recentes
            </h3>
            <Link to="/manage-keys" className="text-xs font-bold text-primary hover:underline">Ver todas</Link>
          </div>
          <div className="space-y-3">
            {keys.length > 0 ? keys.map((key) => (
              <div key={key.id} className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between group hover:border-primary/30 transition-all duration-300">
                <div className="space-y-1">
                  <p className="font-mono text-xs font-bold tracking-wider text-white group-hover:text-primary transition-colors">{key.key_value}</p>
                  <p className="text-[10px] text-white/30 flex items-center gap-1 font-bold uppercase tracking-widest">
                    <Calendar className="w-2.5 h-2.5" /> {new Date(key.created_at).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <Badge className={cn(
                  "capitalize rounded-lg font-bold border-none text-[10px]",
                  key.status === 'active' ? "bg-primary/10 text-primary" : "bg-white/10 text-white/40"
                )}>
                  {key.status === 'active' ? 'Ativa' : key.status}
                </Badge>
              </div>
            )) : (
              <div className="flex flex-col items-center justify-center p-10 bg-white/5 rounded-2xl border border-dashed border-white/10 text-center space-y-3">
                <Key className="w-6 h-6 text-white/10" />
                <p className="text-xs font-bold text-white/30">Nenhuma key gerada ainda.</p>
              </div>
            )}
          </div>
        </section>

        {/* Transactions */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <History className="w-5 h-5 text-primary" /> Transações
            </h3>
          </div>
          <div className="space-y-3">
            {transactions.length > 0 ? transactions.map((tx) => (
              <div key={tx.id} className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between group hover:border-primary/30 transition-all duration-300">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2.5 rounded-lg transition-all group-hover:scale-110",
                    tx.amount > 0 ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                  )}>
                    {tx.amount > 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-white capitalize">{tx.type.replace('_', ' ')}</p>
                    <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest">{tx.description || 'Sem descrição'}</p>
                  </div>
                </div>
                <span className={cn(
                  "font-bold text-base",
                  tx.amount > 0 ? "text-green-500" : "text-red-500"
                )}>
                  {tx.amount > 0 ? '+' : ''}{tx.amount}
                </span>
              </div>
            )) : (
              <div className="flex flex-col items-center justify-center p-10 bg-white/5 rounded-2xl border border-dashed border-white/10 text-center space-y-3">
                <History className="w-6 h-6 text-white/10" />
                <p className="text-xs font-bold text-white/30">Sem histórico de transações.</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
