import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { LoginVersion, ValidityOption } from '../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { 
  ShieldCheck, 
  Clock, 
  Coins, 
  Hash, 
  Smartphone,
  Calculator,
  CheckCircle2,
  Loader2,
  Plus
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export default function GenerateKeysPage() {
  const { profile, refreshProfile } = useAuth();
  const [versions, setVersions] = useState<LoginVersion[]>([]);
  const [options, setOptions] = useState<ValidityOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  // Form State
  const [versionId, setVersionId] = useState<string>('');
  const [optionId, setOptionId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [devices, setDevices] = useState<string>('1');
  const [prefix, setPrefix] = useState<string>('');

  useEffect(() => {
    Promise.all([
      api.getLoginVersions(),
      api.getValidityOptions()
    ]).then(([vData, oData]) => {
      setVersions(vData);
      setOptions(oData);
      setLoading(false);
    });
  }, []);

  const selectedOption = options.find(o => o.id === optionId);
  const creditCostPerKey = selectedOption ? selectedOption.credit_cost : 0;
  const totalCreditsNeeded = creditCostPerKey * quantity;

  const handleGenerate = async () => {
    if (!profile) return;
    if (!versionId || !optionId) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    if (profile.credits < totalCreditsNeeded) {
      toast.error('Créditos insuficientes');
      return;
    }

    setGenerating(true);
    try {
      await api.createKeys({
        userId: profile.id,
        versionId,
        validityHours: selectedOption!.hours,
        devicesAllowed: parseInt(devices),
        creditsUsed: creditCostPerKey,
        quantity,
        prefix
      });
      toast.success(`${quantity} keys geradas com sucesso!`);
      refreshProfile();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao gerar keys');
    } finally {
      setGenerating(false);
    }
  };

  // Defensive check for rendering
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="text-white/40 font-bold uppercase tracking-widest text-xs">Carregando formulário...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-in fade-in duration-500 pb-20">
      <div className="space-y-1">
        <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
          <Plus className="w-6 h-6 text-primary" /> Gerar Keys
        </h2>
        <p className="text-white/40 font-medium italic text-sm">Crie novas keys para seus clientes de forma rápida e eficiente.</p>
      </div>

      <Card className="border-white/5 bg-black/40 backdrop-blur-xl shadow-2xl overflow-hidden rounded-2xl">
        <CardContent className="pt-8 space-y-6 px-6">
          {/* Prefix Personalization */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
              <Plus className="w-3.5 h-3.5 text-primary" /> Personalizar Prefixo
            </Label>
            <Input 
              placeholder="Ex: PDR (Opcional)" 
              className="h-12 bg-white/5 border-white/10 hover:border-primary/50 transition-all text-white font-bold rounded-xl px-4 text-base"
              value={prefix}
              onChange={(e) => setPrefix(e.target.value.toUpperCase())}
            />
            <p className="text-[9px] text-white/20 uppercase tracking-widest font-bold ml-1">As keys serão geradas como PREFIXO-XXXXX</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Version Login */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
                <ShieldCheck className="w-3.5 h-3.5 text-primary" /> Versão de Login <span className="text-red-500">*</span>
              </Label>
              <Select onValueChange={setVersionId} value={versionId || undefined}>
                <SelectTrigger className="h-12 bg-white/5 border-white/10 hover:border-primary/50 transition-all focus:ring-primary/20 text-white rounded-xl px-4 font-bold text-sm">
                  <SelectValue placeholder="Selecione uma versão" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10 text-white rounded-xl">
                  {versions.length > 0 ? (
                    versions.map(v => (
                      <SelectItem key={v.id} value={v.id} className="h-10 focus:bg-primary focus:text-primary-foreground font-bold text-sm">
                        {v.name}
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-3 text-center text-[10px] text-white/20 font-bold">Nenhuma versão disponível</div>
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Validity */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
                <Clock className="w-3.5 h-3.5 text-primary" /> Dias/Horas de Validade <span className="text-red-500">*</span>
              </Label>
              <Select onValueChange={setOptionId} value={optionId || undefined} disabled={!versionId}>
                <SelectTrigger className="h-12 bg-white/5 border-white/10 hover:border-primary/50 transition-all focus:ring-primary/20 text-white rounded-xl px-4 font-bold disabled:opacity-20 text-sm">
                  <SelectValue placeholder="Selecione primeiro a versão" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10 text-white rounded-xl">
                  {options.map(o => (
                    <SelectItem key={o.id} value={o.id} className="h-10 focus:bg-primary focus:text-primary-foreground font-bold text-sm">
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Credits (Read-onlyish) */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
                <Coins className="w-3.5 h-3.5 text-primary" /> Créditos por Key
              </Label>
              <div className="relative">
                <Input 
                  className="h-12 bg-white/5 border-white/10 font-bold text-white rounded-xl px-4 text-base" 
                  value={creditCostPerKey || 0} 
                  readOnly 
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold uppercase tracking-widest text-primary/40 bg-primary/5 px-1.5 py-0.5 rounded-lg">
                  $ Unit.
                </span>
              </div>
            </div>

            {/* Quantity */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
                <Hash className="w-3.5 h-3.5 text-primary" /> Quantidade
              </Label>
              <Input 
                type="number" 
                min="1" 
                className="h-12 bg-white/5 border-white/10 hover:border-primary/50 transition-all text-white font-bold rounded-xl px-4 text-base" 
                value={quantity} 
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
              />
            </div>

            {/* Devices */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest ml-1">
                <Smartphone className="w-3.5 h-3.5 text-primary" /> Dispositivo
              </Label>
              <Select onValueChange={setDevices} value={devices || "1"}>
                <SelectTrigger className="h-12 bg-white/5 border-white/10 hover:border-primary/50 transition-all text-white rounded-xl px-4 font-bold text-sm">
                  <SelectValue placeholder="1 Dispositivo" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10 text-white rounded-xl">
                  <SelectItem value="1" className="h-10 font-bold text-sm">1 Dispositivo</SelectItem>
                  <SelectItem value="2" className="h-10 font-bold text-sm">2 Dispositivos</SelectItem>
                  <SelectItem value="5" className="h-10 font-bold text-sm">5 Dispositivos</SelectItem>
                  <SelectItem value="50" className="h-10 font-bold text-sm">50 Dispositivos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Footer Stats */}
          <div className="bg-white/5 rounded-2xl p-6 border border-white/5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center border border-white/5">
                  <Calculator className="w-5 h-5 text-white/30" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">Total Necessário:</p>
                  <p className="text-[9px] text-white/30 font-bold uppercase tracking-widest">Baseado em validade e quantidade</p>
                </div>
              </div>
              <span className="text-xl font-bold text-white">$ {totalCreditsNeeded.toLocaleString('pt-BR')}</span>
            </div>
            
            <Separator className="bg-white/5" />

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/10">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-bold text-primary">Seus Créditos:</p>
                  <p className="text-[9px] text-primary/40 font-bold uppercase tracking-widest">Saldo disponível agora</p>
                </div>
              </div>
              <span className="text-xl font-bold text-primary">
                $ {(profile?.credits || 0).toLocaleString('pt-BR')}
              </span>
            </div>
          </div>

          <Button 
            className="w-full h-14 text-lg font-bold rounded-xl shadow-2xl shadow-primary/10 group overflow-hidden relative transition-all active:scale-[0.98]" 
            onClick={handleGenerate}
            disabled={generating || !versionId || !optionId || (profile?.credits || 0) < totalCreditsNeeded}
          >
            {generating ? (
              <div className="flex items-center gap-2">
                <Loader2 className="h-5 w-5 animate-spin" />
                Gerando Keys...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Plus className="h-5 w-5 group-hover:rotate-90 transition-transform duration-500" />
                Gerar Keys para Clientes
              </div>
            )}
            
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
