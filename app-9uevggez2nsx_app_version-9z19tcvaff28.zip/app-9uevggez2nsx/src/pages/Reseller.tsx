import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Profile } from '../app_types';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Users, 
  Plus, 
  Minus, 
  UserPlus, 
  Search, 
  MoreHorizontal,
  Wallet,
  TrendingUp,
  Share2
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

export default function ResellerPage() {
  const { profile: resellerProfile, refreshProfile } = useAuth();
  const [subUsers, setSubUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Create User State
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Credit Management State
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [creditAmount, setCreditAmount] = useState<number>(0);
  const [creditDialogOpen, setCreditDialogOpen] = useState(false);
  const [creditAction, setCreditAction] = useState<'add' | 'remove'>('add');

  useEffect(() => {
    if (resellerProfile) {
      fetchSubUsers();
    }
  }, [resellerProfile]);

  const fetchSubUsers = async () => {
    try {
      if (!resellerProfile) return;
      const data = await api.getSubUsers(resellerProfile.id);
      setSubUsers(data);
    } catch (error) {
      console.error('Error fetching sub-users:', error);
      toast.error('Erro ao carregar seus usuários');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async () => {
    if (!newUsername || !newPassword) {
      toast.error('Preencha todos os campos');
      return;
    }
    if (!resellerProfile) return;

    setIsCreating(true);
    try {
      await api.adminCreateUser(newUsername, newPassword, resellerProfile.id);
      toast.success('Usuário criado com sucesso!');
      setCreateDialogOpen(false);
      setNewUsername('');
      setNewPassword('');
      fetchSubUsers();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao criar usuário');
    } finally {
      setIsCreating(false);
    }
  };

  const handleUpdateCredits = async () => {
    if (!selectedUser || creditAmount <= 0 || !resellerProfile) return;
    
    try {
      await api.resellerUpdateCredits(resellerProfile.id, selectedUser.id, creditAmount, creditAction);
      toast.success(`Créditos ${creditAction === 'add' ? 'adicionados' : 'removidos'} com sucesso!`);
      setCreditDialogOpen(false);
      setCreditAmount(0);
      fetchSubUsers();
      refreshProfile();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao atualizar créditos');
    }
  };

  const filteredUsers = subUsers.filter(u => 
    u.username?.toLowerCase().includes(search.toLowerCase()) || 
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
            <Share2 className="w-8 h-8 text-primary" /> Painel do Revendedor
          </h2>
          <p className="text-white/40 font-medium">Gerencie seus próprios clientes e distribua seus créditos.</p>
        </div>

        <div className="flex items-center gap-3">
            <Card className="bg-primary/5 border-primary/20 px-4 py-2 flex items-center gap-3">
                <Wallet className="w-4 h-4 text-primary" />
                <div className="flex flex-col">
                    <span className="text-[10px] uppercase font-black text-primary/60 tracking-wider">Seu Saldo</span>
                    <span className="text-sm font-black text-primary">$ {resellerProfile?.credits?.toLocaleString('pt-BR')}</span>
                </div>
            </Card>

            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
                <DialogTrigger asChild>
                    <Button className="h-12 px-6 font-bold rounded-xl gap-2 shadow-xl shadow-primary/10">
                        <UserPlus className="w-5 h-5" /> Novo Cliente
                    </Button>
                </DialogTrigger>
                <DialogContent className="bg-black border-white/10 text-white">
                    <DialogHeader>
                        <DialogTitle className="text-xl font-black">Adicionar Novo Cliente</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="username">Username</Label>
                            <Input 
                                id="username" 
                                value={newUsername} 
                                onChange={e => setNewUsername(e.target.value)}
                                placeholder="ex: cliente_vips"
                                className="bg-white/5 border-white/10"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="password">Senha</Label>
                            <Input 
                                id="password" 
                                type="password" 
                                value={newPassword} 
                                onChange={e => setNewPassword(e.target.value)}
                                placeholder="••••••••"
                                className="bg-white/5 border-white/10"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setCreateDialogOpen(false)} className="border-white/10">Cancelar</Button>
                        <Button onClick={handleCreateUser} disabled={isCreating} className="font-bold">
                            {isCreating ? 'Criando...' : 'Criar Conta'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                  <Users className="w-6 h-6" />
              </div>
              <div>
                  <p className="text-xs font-bold text-white/40 uppercase tracking-widest">Total de Clientes</p>
                  <p className="text-2xl font-black text-white">{subUsers.length}</p>
              </div>
          </Card>
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-green-500/10 flex items-center justify-center text-green-500">
                  <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                  <p className="text-xs font-bold text-white/40 uppercase tracking-widest">Créditos Distribuídos</p>
                  <p className="text-2xl font-black text-white">{subUsers.reduce((acc, u) => acc + (u.credits || 0), 0)}</p>
              </div>
          </Card>
          <Card className="border-white/5 bg-black/40 backdrop-blur-xl p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                  <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                  <p className="text-xs font-bold text-white/40 uppercase tracking-widest">Conversão Média</p>
                  <p className="text-2xl font-black text-white">8.5%</p>
              </div>
          </Card>
      </div>

      <Card className="border-white/5 bg-black/40 backdrop-blur-xl">
        <CardHeader className="pb-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input 
              placeholder="Pesquisar por username..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-10 bg-white/5 border-white/10 h-12 rounded-xl"
            />
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="rounded-xl border border-white/5 overflow-hidden">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="text-white font-bold text-[10px] uppercase tracking-widest">Cliente</TableHead>
                  <TableHead className="text-white font-bold text-[10px] uppercase tracking-widest text-right">Créditos</TableHead>
                  <TableHead className="text-white font-bold text-[10px] uppercase tracking-widest text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={3} className="text-center py-10 text-white/40">Carregando clientes...</TableCell></TableRow>
                ) : filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-bold text-white group-hover:text-primary transition-colors">{user.username}</span>
                          <span className="text-[10px] text-white/30 uppercase tracking-wider font-bold">Criado em: {new Date(user.created_at).toLocaleDateString('pt-BR')}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-black text-primary">
                        {user.credits?.toLocaleString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="hover:bg-white/10">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-black border-white/10 text-white">
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer focus:bg-primary focus:text-primary-foreground"
                              onClick={() => {
                                setSelectedUser(user);
                                setCreditAction('add');
                                setCreditDialogOpen(true);
                              }}
                            >
                              <Plus className="w-4 h-4" /> Enviar Créditos
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="gap-2 cursor-pointer focus:bg-red-500 focus:text-white"
                              onClick={() => {
                                setSelectedUser(user);
                                setCreditAction('remove');
                                setCreditDialogOpen(true);
                              }}
                            >
                              <Minus className="w-4 h-4" /> Recolher Créditos
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow><TableCell colSpan={3} className="text-center py-10 text-white/40">Nenhum cliente encontrado.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Credit Management Dialog */}
      <Dialog open={creditDialogOpen} onOpenChange={setCreditDialogOpen}>
        <DialogContent className="bg-black border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-black flex items-center gap-2">
              <Wallet className="w-6 h-6 text-primary" /> 
              {creditAction === 'add' ? 'Enviar' : 'Recolher'} Créditos
            </DialogTitle>
            <CardDescription className="text-white/40">
              Cliente: <span className="text-white font-bold">{selectedUser?.username}</span>
            </CardDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Quantidade de Créditos</Label>
              <Input 
                type="number" 
                min="1"
                value={creditAmount || ''} 
                onChange={e => setCreditAmount(parseInt(e.target.value) || 0)}
                placeholder="ex: 100"
                className="bg-white/5 border-white/10 h-12 text-lg font-black"
              />
              {creditAction === 'add' && (
                  <p className="text-xs text-white/40">Os créditos sairão do seu saldo atual.</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreditDialogOpen(false)} className="border-white/10">Cancelar</Button>
            <Button 
              onClick={handleUpdateCredits} 
              className={cn(
                "font-bold",
                creditAction === 'remove' ? "bg-red-500 hover:bg-red-600" : ""
              )}
            >
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
