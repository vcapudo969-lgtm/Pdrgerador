import { supabase } from './supabase';
import { 
  Profile, 
  LoginVersion, 
  ValidityOption, 
  GeneratedKey, 
  Transaction, 
  Complaint, 
  APIKey,
  ValidationEndpoint 
} from '../app_types';

export const api = {
  // Profiles
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (error) console.error('Error fetching profile:', error);
    return data;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId);
    if (error) throw error;
  },

  // Login Versions
  async getLoginVersions(): Promise<LoginVersion[]> {
    const { data, error } = await supabase
      .from('login_versions')
      .select('*')
      .order('name');
    if (error) console.error('Error fetching login versions:', error);
    return data || [];
  },

  // Validity Options
  async getValidityOptions(): Promise<ValidityOption[]> {
    const { data, error } = await supabase
      .from('validity_options')
      .select('*')
      .order('hours');
    if (error) console.error('Error fetching validity options:', error);
    return data || [];
  },

  // Generated Keys
  async getMyKeys(userId: string, limit = 50, offset = 0): Promise<GeneratedKey[]> {
    const { data, error } = await supabase
      .from('generated_keys')
      .select('*, version:login_versions(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    if (error) console.error('Error fetching keys:', error);
    return data || [];
  },

  async createKeys(params: {
    userId: string;
    versionId: string;
    validityHours: number;
    devicesAllowed: number;
    creditsUsed: number;
    quantity: number;
    prefix: string;
  }): Promise<void> {
    const generateCode = () => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let result = '';
      for (let i = 0; i < 5; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    };

    const keys = Array.from({ length: params.quantity }).map(() => {
      const keyValue = params.prefix ? `${params.prefix}-${generateCode()}` : generateCode();
      return {
        user_id: params.userId,
        key_value: keyValue,
        version_id: params.versionId,
        validity_hours: params.validityHours,
        devices_allowed: params.devicesAllowed,
        credits_used: params.creditsUsed,
        status: 'active',
        prefix: params.prefix,
      };
    });

    const { data: profile } = await supabase.from('profiles').select('credits').eq('id', params.userId).single();
    const totalCost = params.creditsUsed * params.quantity;

    if (!profile || profile.credits < totalCost) {
      throw new Error('Créditos insuficientes');
    }

    const { error: updateError } = await supabase
      .from('profiles')
      .update({ credits: profile.credits - totalCost })
      .eq('id', params.userId);
    
    if (updateError) throw updateError;

    const { error: insertError } = await supabase.from('generated_keys').insert(keys);
    if (insertError) {
      await supabase.from('profiles').update({ credits: profile.credits }).eq('id', params.userId);
      throw insertError;
    }

    await supabase.from('transactions').insert({
      user_id: params.userId,
      amount: -totalCost,
      type: 'generate_key',
      description: `Gerou ${params.quantity} keys (${params.prefix})`,
    });
  },

  async pauseKey(keyId: string, currentStatus: string): Promise<void> {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    const pausedAt = newStatus === 'paused' ? new Date().toISOString() : null;
    
    const { error } = await supabase
      .from('generated_keys')
      .update({ status: newStatus, paused_at: pausedAt })
      .eq('id', keyId);
    
    if (error) throw error;
  },

  async resetKey(keyId: string): Promise<void> {
    // Reseta o uso da key (limpa used_at e pode ser usado para reset de HWID no futuro)
    const { error } = await supabase
      .from('generated_keys')
      .update({ used_at: null, status: 'active' })
      .eq('id', keyId);
    
    if (error) throw error;
  },

  async addTimeToAllActiveKeys(hours: number): Promise<void> {
    // Esta função adiciona tempo a todas as keys que estão com status 'active'
    // Como atualmente o tempo é baseado em validity_hours, vamos incrementar esse campo
    const { data: keys, error: fetchError } = await supabase
      .from('generated_keys')
      .select('id, validity_hours')
      .eq('status', 'active');
    
    if (fetchError) throw fetchError;
    if (!keys || keys.length === 0) return;

    // Supabase doesn't support easy bulk increment in a single update call via JS client for different values
    // But we can use an RPC or just update validity_hours + hours
    // For simplicity here, we'll use a loop or better, a direct SQL update via execute_sql if possible
    // But since we are in api.ts, we'll try to use a single update if they all have same increment
    
    const { error } = await supabase.rpc('increment_validity_hours', { hours_to_add: hours });
    
    if (error) {
      // Fallback if RPC doesn't exist (we'll create it in a moment)
      console.error('RPC increment_validity_hours not found, adding via SQL');
      throw error;
    }
  },

  // Transactions
  async getMyTransactions(userId: string): Promise<Transaction[]> {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) console.error('Error fetching transactions:', error);
    return data || [];
  },

  async transferCredits(fromUserId: string, toUsername: string, amount: number): Promise<void> {
    // Find recipient
    const { data: recipient, error: findError } = await supabase
      .from('profiles')
      .select('id, credits')
      .eq('username', toUsername)
      .maybeSingle();

    if (findError || !recipient) throw new Error('Usuário não encontrado');
    if (recipient.id === fromUserId) throw new Error('Não é possível transferir para si mesmo');

    // Get sender
    const { data: sender } = await supabase.from('profiles').select('credits').eq('id', fromUserId).single();
    if (!sender || sender.credits < amount) throw new Error('Créditos insuficientes');

    // Perform transfer
    await supabase.from('profiles').update({ credits: sender.credits - amount }).eq('id', fromUserId);
    await supabase.from('profiles').update({ credits: recipient.credits + amount }).eq('id', recipient.id);

    // Log transactions
    await supabase.from('transactions').insert([
      { user_id: fromUserId, amount: -amount, type: 'transfer_out', description: `Transferência para ${toUsername}` },
      { user_id: recipient.id, amount: amount, type: 'transfer_in', description: `Recebido de ${fromUserId}` },
    ]);
  },

  // Complaints
  async createComplaint(userId: string, subject: string, message: string): Promise<void> {
    const { error } = await supabase.from('complaints').insert({ user_id: userId, subject, message });
    if (error) throw error;
  },

  async getMyComplaints(userId: string): Promise<Complaint[]> {
    const { data, error } = await supabase
      .from('complaints')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) console.error('Error fetching complaints:', error);
    return data || [];
  },

  // API Keys
  async getMyAPIKeys(userId: string): Promise<APIKey[]> {
    const { data, error } = await supabase
      .from('api_keys')
      .select('*')
      .eq('user_id', userId);
    if (error) console.error('Error fetching api keys:', error);
    return data || [];
  },

  async generateAPIKey(userId: string, label: string): Promise<void> {
    const keyValue = 'sk_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const { error } = await supabase.from('api_keys').insert({ user_id: userId, key_value: keyValue, label });
    if (error) throw error;
  },

  async deleteAPIKey(id: string): Promise<void> {
    await supabase.from('api_keys').delete().eq('id', id);
  },

  // Validation Endpoints (Admin)
  async getValidationEndpoints(): Promise<ValidationEndpoint[]> {
    const { data, error } = await supabase
      .from('validation_endpoints')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) console.error('Error fetching validation endpoints:', error);
    return data || [];
  },

  async createValidationEndpoint(name: string, url: string): Promise<void> {
    const { error } = await supabase.from('validation_endpoints').insert({ name, url });
    if (error) throw error;
  },

  async deleteValidationEndpoint(id: string): Promise<void> {
    const { error } = await supabase.from('validation_endpoints').delete().eq('id', id);
    if (error) throw error;
  },

  async toggleValidationEndpoint(id: string, currentStatus: boolean): Promise<void> {
    const { error } = await supabase
      .from('validation_endpoints')
      .update({ is_active: !currentStatus })
      .eq('id', id);
    if (error) throw error;
  },

  // Admin functions
  async getAllUsers(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async adminUpdateCredits(userId: string, amount: number, type: 'add' | 'remove'): Promise<void> {
    const { data: profile } = await supabase.from('profiles').select('credits').eq('id', userId).single();
    if (!profile) throw new Error('Usuário não encontrado');

    const newCredits = type === 'add' ? profile.credits + amount : Math.max(0, profile.credits - amount);

    const { error } = await supabase
      .from('profiles')
      .update({ credits: newCredits })
      .eq('id', userId);
    
    if (error) throw error;

    // Log transaction
    await supabase.from('transactions').insert({
      user_id: userId,
      amount: type === 'add' ? amount : -amount,
      type: type === 'add' ? 'buy' : 'transfer_out',
      description: `Créditos ${type === 'add' ? 'adicionados' : 'removidos'} pelo Administrador`,
    });
  },

  async adminCreateUser(email: string, password: string, username?: string, parentId?: string): Promise<void> {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: username || email.split('@')[0],
          parent_id: parentId
        }
      }
    });
    if (error) throw error;
  },

  async promoteToAdmin(userId: string): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({ role: 'admin' })
      .eq('id', userId);
    if (error) throw error;
  },

  async demoteFromAdmin(userId: string): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({ role: 'user' })
      .eq('id', userId);
    if (error) throw error;
  },

  async deleteUser(userId: string): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', userId);
    if (error) throw error;
  },

  async getSubUsers(parentId: string): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('parent_id', parentId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async resellerUpdateCredits(resellerId: string, subUserId: string, amount: number, type: 'add' | 'remove'): Promise<void> {
    // Check reseller balance
    const { data: reseller } = await supabase.from('profiles').select('credits').eq('id', resellerId).single();
    if (!reseller) throw new Error('Revendedor não encontrado');

    const { data: subUser } = await supabase.from('profiles').select('credits').eq('id', subUserId).single();
    if (!subUser) throw new Error('Usuário não encontrado');

    if (type === 'add' && reseller.credits < amount) {
      throw new Error('Saldo insuficiente para adicionar créditos');
    }

    const newResellerCredits = type === 'add' ? reseller.credits - amount : reseller.credits + amount;
    const newSubUserCredits = type === 'add' ? subUser.credits + amount : Math.max(0, subUser.credits - amount);

    // Update reseller
    await supabase.from('profiles').update({ credits: newResellerCredits }).eq('id', resellerId);
    // Update subuser
    await supabase.from('profiles').update({ credits: newSubUserCredits }).eq('id', subUserId);

    // Log transactions
    await supabase.from('transactions').insert([
      { 
        user_id: resellerId, 
        amount: type === 'add' ? -amount : amount, 
        type: 'transfer_out', 
        description: `Créditos ${type === 'add' ? 'enviados' : 'recolhidos'} para sub-usuário` 
      },
      { 
        user_id: subUserId, 
        amount: type === 'add' ? amount : -amount, 
        type: 'transfer_in', 
        description: `Créditos ${type === 'add' ? 'recebidos' : 'devolvidos'} do revendedor` 
      }
    ]);
  },

  async getUsageStats(userId: string): Promise<{ date: string; count: number }[]> {
    const { data, error } = await supabase
      .from('generated_keys')
      .select('created_at')
      .eq('user_id', userId)
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());
    
    if (error) {
      console.error('Error fetching usage stats:', error);
      return [];
    }

    // Process data for chart
    const stats: Record<string, number> = {};
    const last7Days = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    last7Days.forEach(date => stats[date] = 0);

    data.forEach(item => {
      const date = item.created_at.split('T')[0];
      if (stats[date] !== undefined) {
        stats[date]++;
      }
    });

    return Object.entries(stats).map(([date, count]) => ({ date, count }));
  }
};
