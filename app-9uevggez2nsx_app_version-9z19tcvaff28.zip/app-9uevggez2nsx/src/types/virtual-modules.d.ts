// src/types/virtual-modules.d.ts

declare module '@/db/supabase' {
  export const supabase: ReturnType<typeof import('@supabase/supabase-js').createClient>;
}

declare module '@/app_types' {
  export interface Profile {
    [key: string]: unknown;
  }
}
