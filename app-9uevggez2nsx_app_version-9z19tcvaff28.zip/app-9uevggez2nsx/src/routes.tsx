import { Navigate } from 'react-router-dom';

interface RouteConfig {
  path: string;
  element: React.ReactNode;
  auth?: boolean;
}

import LoginPage from './pages/Login';
import Dashboard from './pages/Dashboard';
import GenerateKeysPage from './pages/GenerateKeys';
import ManageKeysPage from './pages/ManageKeys';
import TransferCreditsPage from './pages/TransferCredits';
import ProfilePage from './pages/Profile';
import APIKeysPage from './pages/APIKeys';
import WalletPage from './pages/Wallet';
import AffiliatePage from './pages/Affiliate';
import ResellerPage from './pages/Reseller';
import ComplaintsPage from './pages/Complaints';
import UserManagement from './pages/admin/UserManagement';
import APIsManagement from './pages/admin/APIs';
import APIDocs from './pages/APIDocs';
import { DashboardLayout } from './components/layouts/DashboardLayout';

export const routes: RouteConfig[] = [
  {
    path: '/admin/users',
    element: (
      <DashboardLayout>
        <UserManagement />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/admin/apis',
    element: (
      <DashboardLayout>
        <APIsManagement />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/api-keys',
    element: (
      <DashboardLayout>
        <APIKeysPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/wallet',
    element: (
      <DashboardLayout>
        <WalletPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/affiliate',
    element: (
      <DashboardLayout>
        <AffiliatePage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/api-docs',
    element: (
      <DashboardLayout>
        <APIDocs />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/login',
    element: <LoginPage />,
    auth: false,
  },
  {
    path: '/dashboard',
    element: (
      <DashboardLayout>
        <Dashboard />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/generate-keys',
    element: (
      <DashboardLayout>
        <GenerateKeysPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/manage-keys',
    element: (
      <DashboardLayout>
        <ManageKeysPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/transfer-credits',
    element: (
      <DashboardLayout>
        <TransferCreditsPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/profile',
    element: (
      <DashboardLayout>
        <ProfilePage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/reseller',
    element: (
      <DashboardLayout>
        <ResellerPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/complaints',
    element: (
      <DashboardLayout>
        <ComplaintsPage />
      </DashboardLayout>
    ),
    auth: true,
  },
  {
    path: '/',
    element: <Navigate to="/dashboard" replace />,
  },
];
