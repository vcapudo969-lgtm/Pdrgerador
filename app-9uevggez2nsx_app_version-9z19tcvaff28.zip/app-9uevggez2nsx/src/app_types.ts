export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type Profile = {
  id: string;
  email: string | null;
  username: string | null;
  role: 'user' | 'admin' | 'super_admin';
  credits: number;
  affiliate_link: string | null;
  parent_id: string | null;
  created_at: string;
};

export type LoginVersion = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

export type ValidityOption = {
  id: string;
  label: string;
  hours: number;
  credit_cost: number;
  created_at: string;
};

export type GeneratedKey = {
  id: string;
  user_id: string;
  key_value: string;
  version_id: string;
  validity_hours: number;
  devices_allowed: number;
  credits_used: number;
  status: 'active' | 'used' | 'expired' | 'paused';
  prefix: string | null;
  expires_at: string | null;
  paused_at: string | null;
  used_at: string | null;
  created_at: string;
  version?: LoginVersion;
};

export type Transaction = {
  id: string;
  user_id: string;
  amount: number;
  type: 'buy' | 'generate_key' | 'transfer_in' | 'transfer_out';
  description: string | null;
  created_at: string;
};

export type Complaint = {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'pending' | 'resolved';
  created_at: string;
};

export type APIKey = {
  id: string;
  user_id: string;
  key_value: string;
  label: string | null;
  created_at: string;
};

export type ValidationEndpoint = {
  id: string;
  name: string;
  url: string;
  is_active: boolean;
  created_at: string;
};
