import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    
    // Suporte para token tanto no header quanto no corpo (conforme exemplo do usuário)
    const authHeader = req.headers.get("Authorization");
    let apiKey = authHeader ? authHeader.replace("Bearer ", "").trim() : null;
    
    let body = {};
    if (req.method === "POST") {
      body = await req.json().catch(() => ({}));
      if (!apiKey) {
        apiKey = (body.token || body.master_key || "").trim();
      }
    }

    if (!apiKey) return new Response(JSON.stringify({ error: "Token de acesso ausente." }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    let userId: string;
    if (apiKey === "JACINTOPINTOEREBOLO") {
      userId = "03a833cc-bdf9-4b90-b896-5e268e9cf51b";
    } else {
      const { data: apiKeyData, error: apiKeyError } = await supabaseClient.from("api_keys").select("user_id").eq("key_value", apiKey).single();
      if (apiKeyError || !apiKeyData) return new Response(JSON.stringify({ error: "API Key inválida." }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      userId = apiKeyData.user_id;
    }

    const currentUserId = userId;
    const url = new URL(req.url);
    const path = url.pathname.split("/").filter(Boolean).pop();

    if (req.method === "POST" && path === "generate") {
      // Mapeamento de campos do exemplo do usuário para o sistema interno
      const botName = body.bot_name || body.prefix || "BOT";
      let version_id = body.version_id;
      const versionName = body.version_name;
      let validity_hours = Number(body.validity_hours);
      let credit_cost = Number(body.credit_cost);
      const quantity = Math.max(1, Math.min(100, Number(body.quantity || 1)));
      const devices = Number(body.devices || 1);
      const targetUsername = body.target_username;

      // Determine target user ID (Default to the API Key owner or Master Admin)
      let finalUserId = currentUserId;

      if (targetUsername && apiKey === "JACINTOPINTOEREBOLO") {
        const { data: targetUser } = await supabaseClient
          .from("profiles")
          .select("id")
          .or(`username.eq.${targetUsername},email.eq.${targetUsername}`)
          .maybeSingle();
        if (targetUser) finalUserId = targetUser.id;
      }

      // Se campos obrigatórios estiverem ausentes, busca padrões
      if (!version_id && versionName) {
        const { data: v } = await supabaseClient.from("login_versions").select("id").eq("name", versionName).maybeSingle();
        version_id = v?.id;
      }

      if (!version_id) {
        const { data: firstVersion } = await supabaseClient.from("login_versions").select("id").limit(1).single();
        version_id = firstVersion?.id;
      } else {
        // Valida se version_id ou version_name existe
        const { data: vExists } = await supabaseClient.from("login_versions").select("id, name").or(`id.eq.${version_id},name.eq.${version_id}`).maybeSingle();
        if (!vExists) {
          const { data: allV } = await supabaseClient.from("login_versions").select("name");
          return new Response(JSON.stringify({ error: `Versão '${version_id}' não encontrada.`, available_versions: allV?.map(v => v.name) || [] }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        version_id = vExists.id;
      }
      
      if (isNaN(validity_hours)) validity_hours = 24;
      
      const { data: valOpt } = await supabaseClient.from("validity_options").select("credit_cost, hours, label").eq("hours", validity_hours).limit(1).maybeSingle();
      if (!valOpt) {
        const { data: allOpts } = await supabaseClient.from("validity_options").select("hours, label");
        return new Response(JSON.stringify({ error: `Validade de ${validity_hours}h inválida.`, available_validities: allOpts || [] }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      credit_cost = valOpt.credit_cost;

      if (!version_id) return new Response(JSON.stringify({ error: "Nenhuma versão de login disponível." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      const { data: profile } = await supabaseClient.from("profiles").select("credits").eq("id", finalUserId).single();
      const totalCost = credit_cost * quantity;

      if (!profile || profile.credits < totalCost) {
        return new Response(JSON.stringify({ error: `Saldo insuficiente do usuário. Disponível: ${profile?.credits || 0}` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      const keys = [];
      for (let i = 0; i < quantity; i++) {
        let code = "";
        for (let j = 0; j < 5; j++) code += chars.charAt(Math.floor(Math.random() * chars.length));
        keys.push({ 
          user_id: finalUserId, 
          key_value: botName ? `${botName}-${code}` : code, 
          version_id, 
          validity_hours, 
          devices_allowed: devices, 
          credits_used: credit_cost, 
          status: "active", 
          prefix: botName || null 
        });
      }

      const { error: updateError } = await supabaseClient.from("profiles").update({ credits: profile.credits - totalCost }).eq("id", finalUserId);
      if (updateError) return new Response(JSON.stringify({ error: "Erro ao descontar créditos." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      const { data: insertedKeys, error: insertError } = await supabaseClient.from("generated_keys").insert(keys).select();
      if (insertError) {
        await supabaseClient.from("profiles").update({ credits: profile.credits }).eq("id", finalUserId);
        return new Response(JSON.stringify({ error: "Erro ao salvar chaves." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      await supabaseClient.from("transactions").insert({ user_id: finalUserId, amount: -totalCost, type: "generate_key", description: `Via API Node.js (${botName})` });
      
      // Retorna no formato simplificado para bots
      return new Response(JSON.stringify({ 
        success: true, 
        message: "✅ Key gerada com sucesso!",
        data: {
          key_value: insertedKeys[0].key_value
        },
        keys: insertedKeys 
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "POST" && path === "validate") {
      const { key } = body;
      if (!key) return new Response(JSON.stringify({ error: "Parâmetro 'key' obrigatório." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const { data: keyData, error } = await supabaseClient.from("generated_keys").select("*, login_versions(name)").eq("key_value", key).single();
      if (error || !keyData) return new Response(JSON.stringify({ valid: false, error: "Key não encontrada." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      let valid = keyData.status === "active";
      if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
        valid = false;
        await supabaseClient.from("generated_keys").update({ status: "expired" }).eq("id", keyData.id);
      }
      return new Response(JSON.stringify({ valid, status: keyData.status, version: keyData.login_versions?.name, expires_at: keyData.expires_at, devices: keyData.devices_allowed }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "POST" && path === "bot-check") {
      const { key } = body;
      if (!key) return new Response(JSON.stringify({ error: "Key não informada." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      
      const { data: keyData, error } = await supabaseClient
        .from("generated_keys")
        .select("*, login_versions(name)")
        .eq("key_value", key)
        .maybeSingle();

      if (error || !keyData) {
        return new Response(JSON.stringify({ 
          status: "not_found", 
          message: "❌ Key inválida ou não encontrada no sistema." 
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      let status = keyData.status;
      let message = "";

      // Check expiration
      if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
        status = "expired";
        await supabaseClient.from("generated_keys").update({ status: "expired" }).eq("id", keyData.id);
      }

      switch (status) {
        case "active":
          message = "✅ Sua Key está ATIVA e pronta para uso!";
          break;
        case "paused":
          message = "⚠️ Sua Key está PAUSADA pelo administrador.";
          break;
        case "expired":
          message = "❌ Sua Key está EXPIRADA. Por favor, adquira uma nova.";
          break;
        case "used":
          message = "📱 Sua Key já está EM USO em um dispositivo.";
          break;
        default:
          message = `ℹ️ Status da Key: ${status}`;
      }

      return new Response(JSON.stringify({ 
        status, 
        message, 
        version: keyData.login_versions?.name,
        expires_at: keyData.expires_at 
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "POST" && path === "manage") {
      const { key, action } = body;
      if (!key || !action) return new Response(JSON.stringify({ error: "Parâmetros 'key' e 'action' são obrigatórios." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      
      const { data: keyData, error: findError } = await supabaseClient
        .from("generated_keys")
        .select("*")
        .eq("key_value", key)
        .maybeSingle();

      if (findError || !keyData) return new Response(JSON.stringify({ error: "Key não encontrada." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      // Permissão: Master Token pode tudo, usuários comuns apenas suas próprias keys
      if (apiKey !== "JACINTOPINTOEREBOLO" && keyData.user_id !== currentUserId) {
        return new Response(JSON.stringify({ error: "Acesso negado. Esta key não pertence à sua conta." }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      let updateData: any = {};
      let responseMessage = "";

      switch (action) {
        case "pause":
          updateData = { status: "paused" };
          responseMessage = "⏸️ Key pausada com sucesso!";
          break;
        case "resume":
        case "unpause":
          updateData = { status: "active" };
          responseMessage = "▶️ Key reativada com sucesso!";
          break;
        case "reset":
          updateData = { hwid: null, last_login: null };
          responseMessage = "🔄 HWID da Key resetado com sucesso!";
          break;
        case "ban":
          updateData = { status: "banned" };
          responseMessage = "🚫 Key banida com sucesso!";
          break;
        default:
          return new Response(JSON.stringify({ error: "Ação inválida. Use: pause, resume, reset, ban." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { error: updateError } = await supabaseClient
        .from("generated_keys")
        .update(updateData)
        .eq("id", keyData.id);

      if (updateError) return new Response(JSON.stringify({ error: "Erro ao atualizar a key." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      return new Response(JSON.stringify({ success: true, message: responseMessage, status: updateData.status || keyData.status }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "GET" && path === "me") {
      const { data: profile, error } = await supabaseClient.from("profiles").select("*").eq("id", currentUserId).single();
      if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      return new Response(JSON.stringify(profile), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "GET" && path === "versions") {
      const { data, error } = await supabaseClient.from("login_versions").select("*").order("name");
      if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      return new Response(JSON.stringify(data), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (req.method === "GET" && path === "validity") {
      const { data, error } = await supabaseClient.from("validity_options").select("*").order("hours");
      if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      return new Response(JSON.stringify(data), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ message: "API Bot Ativa", user_id: currentUserId }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
