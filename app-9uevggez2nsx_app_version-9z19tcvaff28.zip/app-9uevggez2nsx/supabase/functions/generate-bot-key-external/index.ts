import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Parse request body
    const body = await req.json().catch(() => ({}));
    const { 
      bot_name, 
      description, 
      token: req_token, 
      master_key,
      target_username, 
      version_name, 
      validity_hours: req_hours, 
      devices: req_devices, 
      key: key_to_check, 
      action 
    } = body;

    const token = (req_token || master_key || "").trim();

    // Handle Check Action
    if (action === "check" || key_to_check) {
      if (!key_to_check) return new Response(JSON.stringify({ error: "Key não informada." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      
      const { data: keyData, error } = await supabaseClient
        .from("generated_keys")
        .select("*, login_versions(name)")
        .eq("key_value", key_to_check)
        .maybeSingle();

      if (error || !keyData) {
        return new Response(JSON.stringify({ 
          status: "not_found", 
          message: "❌ Key inválida ou não encontrada no sistema." 
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      let status = keyData.status;
      let message = "";

      if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
        status = "expired";
        await supabaseClient.from("generated_keys").update({ status: "expired" }).eq("id", keyData.id);
      }

      switch (status) {
        case "active": message = "✅ Sua Key está ATIVA e pronta para uso!"; break;
        case "paused": message = "⚠️ Sua Key está PAUSADA pelo administrador."; break;
        case "expired": message = "❌ Sua Key está EXPIRADA. Por favor, adquira uma nova."; break;
        case "used": message = "📱 Sua Key já está EM USO em um dispositivo."; break;
        default: message = `ℹ️ Status da Key: ${status}`;
      }

      return new Response(JSON.stringify({ status, message, version: keyData.login_versions?.name, expires_at: keyData.expires_at }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Validate token
    if (token !== "JACINTOPINTOEREBOLO") {
      return new Response(JSON.stringify({ error: "Token de autenticação inválido." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Handle Management Action
    if (action === "pause" || action === "resume" || action === "reset" || action === "ban") {
      const keyToManage = body.key || key_to_check;
      if (!keyToManage) return new Response(JSON.stringify({ error: "Key não informada." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      const { data: keyData, error: findError } = await supabaseClient
        .from("generated_keys")
        .select("*")
        .eq("key_value", keyToManage)
        .maybeSingle();

      if (findError || !keyData) return new Response(JSON.stringify({ error: "Key não encontrada." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      let updateData: any = {};
      let responseMessage = "";

      switch (action) {
        case "pause": updateData = { status: "paused" }; responseMessage = "⏸️ Key pausada com sucesso!"; break;
        case "resume": updateData = { status: "active" }; responseMessage = "▶️ Key reativada com sucesso!"; break;
        case "reset": updateData = { hwid: null, last_login: null }; responseMessage = "🔄 HWID resetado!"; break;
        case "ban": updateData = { status: "banned" }; responseMessage = "🚫 Key banida!"; break;
      }

      const { error: updateError } = await supabaseClient.from("generated_keys").update(updateData).eq("id", keyData.id);
      if (updateError) return new Response(JSON.stringify({ error: "Erro ao gerenciar a key." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });

      return new Response(JSON.stringify({ success: true, message: responseMessage }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Validate required fields
    if (!bot_name) {
      return new Response(JSON.stringify({ error: "O campo 'bot_name' é obrigatório." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Determine target user ID (Default to Super Admin if target_username is not provided)
    let userId = "03a833cc-bdf9-4b90-b896-5e268e9cf51b";

    if (target_username) {
      const { data: targetUser, error: userError } = await supabaseClient
        .from("profiles")
        .select("id")
        .or(`username.eq.${target_username},email.eq.${target_username}`)
        .maybeSingle();
      
      if (userError || !targetUser) {
        return new Response(JSON.stringify({ error: `Usuário ou E-mail '${target_username}' não encontrado.` }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      userId = targetUser.id;
    }

    // Get version to use
    let version_id: string;
    const { data: allVersions } = await supabaseClient.from("login_versions").select("name");
    const availableVersions = allVersions?.map((v: any) => v.name).join(", ") || "";

    if (version_name) {
      const { data: v } = await supabaseClient
        .from("login_versions")
        .select("id")
        .eq("name", version_name)
        .maybeSingle();
      if (!v) {
        return new Response(JSON.stringify({ 
          error: `Versão '${version_name}' não encontrada.`,
          available_versions: allVersions?.map((v: any) => v.name) || []
        }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      version_id = v.id;
    } else {
      const { data: versions } = await supabaseClient
        .from("login_versions")
        .select("id")
        .limit(1)
        .single();

      if (!versions) {
        return new Response(JSON.stringify({ error: "Nenhuma versão de login configurada no sistema." }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      version_id = versions.id;
    }

    // Determine validity and cost
    let validityHours = Number(req_hours) || 24;
    let creditCost = 5;

    const { data: allOpts } = await supabaseClient.from("validity_options").select("hours, label");
    const { data: valOpt } = await supabaseClient
      .from("validity_options")
      .select("credit_cost")
      .eq("hours", validityHours)
      .maybeSingle();

    if (valOpt) {
      creditCost = valOpt.credit_cost;
    } else {
      // Only error if req_hours was provided. If not, use 24h as default (which must exist in validity_options)
      if (req_hours) {
        return new Response(JSON.stringify({ 
          error: `A validade de ${req_hours} horas não é válida.`,
          available_validities: allOpts || []
        }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Check credits for the admin
    const { data: profile } = await supabaseClient
      .from("profiles")
      .select("credits")
      .eq("id", userId)
      .single();

    if (!profile || profile.credits < creditCost) {
      return new Response(JSON.stringify({ error: "Saldo insuficiente para a geração da chave." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Generate the key value
    const generateCode = () => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      let result = "";
      for (let i = 0; i < 5; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    };

    const keyValue = `${bot_name}-${generateCode()}`;

    // Deduct credits
    const { error: updateError } = await supabaseClient
      .from("profiles")
      .update({ credits: profile.credits - creditCost })
      .eq("id", userId);

    if (updateError) {
      return new Response(JSON.stringify({ error: "Erro ao atualizar créditos." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create the key
    const { data: insertedKey, error: insertError } = await supabaseClient
      .from("generated_keys")
      .insert({
        user_id: userId,
        key_value: keyValue,
        version_id: version_id,
        validity_hours: validityHours,
        devices_allowed: devices,
        credits_used: creditCost,
        status: "active",
        prefix: bot_name,
      })
      .select()
      .single();

    if (insertError) {
      // Rollback credits
      await supabaseClient.from("profiles").update({ credits: profile.credits }).eq("id", userId);
      return new Response(JSON.stringify({ error: "Erro ao gerar chave." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Log transaction
    await supabaseClient.from("transactions").insert({
      user_id: userId,
      amount: -creditCost,
      type: "generate_key",
      description: `Key gerada via API externa para o bot: ${bot_name}. ${description || ''}`,
    });

    // Final response exactly matching the requested format
    return new Response(
      JSON.stringify({
        data: {
          key_value: insertedKey.key_value,
        },
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
