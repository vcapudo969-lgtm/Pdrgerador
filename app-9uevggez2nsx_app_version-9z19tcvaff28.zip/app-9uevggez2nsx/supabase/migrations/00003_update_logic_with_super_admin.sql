-- Add parent_id to profiles to track who created who (reseller logic)
ALTER TABLE public.profiles ADD COLUMN parent_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

-- Update handle_new_user to use super_admin for the first user and start with 0 credits
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM public.profiles;
  INSERT INTO public.profiles (id, email, username, role, credits, affiliate_link)
  VALUES (
    NEW.id,
    NEW.email,
    SPLIT_PART(NEW.email, '@', 1),
    CASE 
      WHEN user_count = 0 THEN 'super_admin'::public.user_role 
      ELSE 'user'::public.user_role 
    END,
    0, -- Start with 0 credits
    'https://geradorkeys.com/reseller/' || SPLIT_PART(NEW.email, '@', 1)
  );
  RETURN NEW;
END;
$$;

-- Update is_admin helper to include super_admin
CREATE OR REPLACE FUNCTION public.is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = uid AND p.role IN ('admin'::public.user_role, 'super_admin'::public.user_role)
  );
$$;

-- Helper for super_admin
CREATE OR REPLACE FUNCTION public.is_super_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = uid AND p.role = 'super_admin'::public.user_role
  );
$$;

-- Update Profile Policies
-- Clean up old policies first
DROP POLICY IF EXISTS "Admins full access to profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;

-- Super admins have full access
CREATE POLICY "Super admins full access" ON public.profiles FOR ALL TO authenticated USING (public.is_super_admin(auth.uid()));

-- Admins can manage users but not super_admins
CREATE POLICY "Admins manage users" ON public.profiles FOR ALL TO authenticated 
USING (
  public.is_admin(auth.uid()) AND 
  (role = 'user'::public.user_role OR id = auth.uid())
);

-- Users see their own profile
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);

-- Resellers can see sub-users
CREATE POLICY "Resellers can see sub-users" ON public.profiles FOR SELECT TO authenticated USING (parent_id = auth.uid());

-- Resellers can update their sub-users credits
CREATE POLICY "Resellers can update sub-users" ON public.profiles FOR UPDATE TO authenticated USING (parent_id = auth.uid());
