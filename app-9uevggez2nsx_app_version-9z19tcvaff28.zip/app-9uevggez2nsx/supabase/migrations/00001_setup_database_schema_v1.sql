-- Create user roles
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- Profiles table
CREATE TABLE public.profiles (
  id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email text,
  username text UNIQUE,
  role public.user_role DEFAULT 'user'::public.user_role,
  credits integer DEFAULT 0,
  affiliate_link text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Login versions (v1, v2, v3, etc.)
CREATE TABLE public.login_versions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Validity options (1 day, 1 month, etc.)
CREATE TABLE public.validity_options (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  label text NOT NULL, -- e.g., '1 Dia', '30 Dias'
  hours integer NOT NULL,
  credit_cost integer NOT NULL,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Generated keys
CREATE TABLE public.generated_keys (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  key_value text NOT NULL UNIQUE,
  version_id uuid REFERENCES public.login_versions(id) NOT NULL,
  validity_hours integer NOT NULL,
  devices_allowed integer DEFAULT 1,
  credits_used integer NOT NULL,
  status text DEFAULT 'active', -- active, used, expired
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Transactions (credit history)
CREATE TABLE public.transactions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  amount integer NOT NULL,
  type text NOT NULL, -- 'buy', 'generate_key', 'transfer_in', 'transfer_out'
  description text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Complaints (reclamacoes)
CREATE TABLE public.complaints (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  status text DEFAULT 'pending', -- pending, resolved
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- API Keys
CREATE TABLE public.api_keys (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  key_value text NOT NULL UNIQUE,
  label text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- RLS & Policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.login_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.validity_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

-- Helper: is_admin
CREATE OR REPLACE FUNCTION public.is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = uid AND p.role = 'admin'::public.user_role
  );
$$;

-- Profile Policies
CREATE POLICY "Admins full access to profiles" ON public.profiles FOR ALL TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) 
WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM public.profiles WHERE id = auth.uid()));

-- Login Versions Policies
CREATE POLICY "Everyone can see login versions" ON public.login_versions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage versions" ON public.login_versions FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- Validity Options Policies
CREATE POLICY "Everyone can see validity options" ON public.validity_options FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage options" ON public.validity_options FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- Generated Keys Policies
CREATE POLICY "Users see own keys" ON public.generated_keys FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users create keys" ON public.generated_keys FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins manage all keys" ON public.generated_keys FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- Transactions Policies
CREATE POLICY "Users see own transactions" ON public.transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert transactions" ON public.transactions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins manage all transactions" ON public.transactions FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- Complaints Policies
CREATE POLICY "Users see own complaints" ON public.complaints FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert complaints" ON public.complaints FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins manage all complaints" ON public.complaints FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- API Keys Policies
CREATE POLICY "Users see own api keys" ON public.api_keys FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert api keys" ON public.api_keys FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins manage all api keys" ON public.api_keys FOR ALL TO authenticated USING (public.is_admin(auth.uid()));

-- Auth Trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM public.profiles;
  INSERT INTO public.profiles (id, email, username, role, credits, affiliate_link)
  VALUES (
    NEW.id,
    NEW.email,
    SPLIT_PART(NEW.email, '@', 1),
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END,
    100, -- Initial credits for demo
    'https://geradorkeys.com/ref/' || SPLIT_PART(NEW.email, '@', 1)
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION public.handle_new_user();

-- Seed data for testing
INSERT INTO public.login_versions (name, description) VALUES 
('Versão Standard', 'Versão básica do login'),
('Versão Premium', 'Versão com recursos extras'),
('Versão Mobile', 'Específica para dispositivos móveis');

INSERT INTO public.validity_options (label, hours, credit_cost) VALUES 
('1 Hora', 1, 1),
('2 Horas', 2, 2),
('12 Horas', 12, 10),
('1 Dia', 24, 20),
('7 Dias', 168, 100),
('30 Dias', 720, 300);
