create or replace function increment_validity_hours(hours_to_add int)
returns void as $$
begin
  update generated_keys
  set validity_hours = validity_hours + hours_to_add
  where status = 'active';
end;
$$ language plpgsql;
