create table if not exists validation_endpoints (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  url text not null,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

-- Seed with a sample endpoint if needed
insert into validation_endpoints (name, url) values ('API Oficial', 'https://api.pdrgerador.com/v1/validate');
