ALTER TYPE public.user_role ADD VALUE 'super_admin';
