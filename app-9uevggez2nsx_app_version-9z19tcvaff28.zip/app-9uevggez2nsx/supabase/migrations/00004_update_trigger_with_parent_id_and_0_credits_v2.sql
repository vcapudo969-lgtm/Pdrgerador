CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_from_meta text;
  parent_id_from_meta uuid;
BEGIN
  SELECT COUNT(*) INTO user_count FROM public.profiles;
  
  -- Extract from user metadata if provided
  username_from_meta := NEW.raw_user_meta_data->>'username';
  IF username_from_meta IS NULL THEN
    username_from_meta := SPLIT_PART(NEW.email, '@', 1);
  END IF;

  parent_id_from_meta := (NEW.raw_user_meta_data->>'parent_id')::uuid;

  INSERT INTO public.profiles (id, email, username, role, credits, affiliate_link, parent_id)
  VALUES (
    NEW.id,
    NEW.email,
    username_from_meta,
    CASE 
      WHEN user_count = 0 THEN 'super_admin'::public.user_role 
      ELSE 'user'::public.user_role 
    END,
    0, -- Start with 0 credits
    'https://geradorkeys.com/reseller/' || username_from_meta,
    parent_id_from_meta
  );
  RETURN NEW;
END;
$$;
