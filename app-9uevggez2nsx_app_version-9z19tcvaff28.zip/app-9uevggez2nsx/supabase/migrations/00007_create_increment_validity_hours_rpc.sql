CREATE OR REPLACE FUNCTION public.increment_validity_hours(hours_to_add int)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.generated_keys
  SET validity_hours = validity_hours + hours_to_add
  WHERE status = 'active';
END;
$$;