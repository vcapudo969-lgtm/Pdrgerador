# Gerador de Keys - Documento de Requisitos

## 1. Informações Básicas

### 1.1 Nome da Aplicação
Gerador de Keys

### 1.2 Descrição da Aplicação
Ferramenta para geração de chaves (keys) para clientes de forma rápida e eficiente, com controle de versões de login, validade, créditos e dispositivos. Sistema com hierarquia de permissões (Super Admin, Admin e Revendedor).

## 2. Funcionalidades Principais

### 2.1 Sistema de Login
- Tela de login (sem opção de registro)
- Novos usuários são criados por Super Admin ou Revendedores
- Usuários iniciam com 0 créditos
- Usuário pedrosensi possui permissão de Super Admin

### 2.2 Hierarquia de Permissões

#### 2.2.1 Super Admin
- Adicionar e gerenciar novos Admins
- Remover permissão de Admin de usuários
- Excluir usuários do sistema
- Acesso completo a todas as funcionalidades do sistema
- Usuário pedrosensi possui este nível de permissão

#### 2.2.2 Admin
- Acesso às funcionalidades padrão do sistema
- Gerenciamento de APIs para validação de keys
- API específica para bots gerarem keys automaticamente
- Acrescentar tempo em todas as keys ativas

#### 2.2.3 Revendedor
- Criar logins de usuários
- Gerenciar usuários criados
- Adicionar créditos aos usuários (deduzidos do próprio saldo)
- Remover créditos dos usuários (retornam ao próprio saldo)

### 2.3 Geração de Keys
- Seleção de versão de login (dropdown):
  - Rage Android
  - Lite
- Configuração de dias/horas de validade (dropdown):
  - 1 dia: 5 créditos
  - 7 dias: 10 créditos
  - 15 dias: 20 créditos
  - 30 dias: 30 créditos
- Definição de quantidade de créditos (campo numérico com preenchimento automático baseado na validade)
- Definição de quantidade de keys a gerar (campo numérico)
- Seleção de número de dispositivos permitidos (dropdown)
- Personalizar key por prefixo (campo de texto)
- Exibição do total de créditos necessários
- Exibição dos créditos disponíveis do usuário
- Botão para gerar keys
- Sistema desconta créditos do usuário após geração das keys
- Keys geradas no formato: [PREFIXO]-[CÓDIGO DE 5 DÍGITOS]

### 2.4 Gerenciamento de Keys
- Visualização de keys geradas (menu lateral com opção Gerenciar Keys)
- Pausar key
- Resetar key

### 2.5 Dashboard
- Painel principal com visão geral do sistema
- Personalizar key por prefixo

### 2.6 Carteira
- Transferência de créditos entre usuários
- Personalizar key por prefixo

### 2.7 Perfil
- Visualização e edição do perfil do usuário
- Sistema de reclamações
- Personalizar key por prefixo

### 2.8 Revendedor
- Criar novos logins de usuários
- Gerenciar usuários criados
- Adicionar créditos (deduzidos do saldo do revendedor)
- Remover créditos (retornam ao saldo do revendedor)
- Personalizar key por prefixo

### 2.9 APIs de Validação (Painel Admin)
- Gerenciamento de APIs para validação de keys
- Configuração de endpoints de validação
- Nova API específica para bots gerarem keys automaticamente em Node.js (substituindo a API anterior que estava offline)
- Autenticação via token: JACINTOPINTOEREBOLO
- Qualquer bot que possua o token JACINTOPINTOEREBOLO consegue gerar keys através da API
- Parâmetros da API para geração de keys:
  - Versão de login
  - Validade (dias/horas)
  - Quantidade de créditos
  - Quantidade de keys
  - Número de dispositivos permitidos
  - Prefixo personalizado
- API de validação de key para bot:
  - Bot envia comando com a key
  - Sistema responde com status da key: ativa, pausada ou expirada
  - Autenticação via token: JACINTOPINTOEREBOLO
- API de gerenciamento de keys para bot em Node.js:
  - Bot envia a key que deseja gerenciar
  - Bot consegue pausar a key
  - Bot consegue resetar a key
  - Bot consegue banir a key
  - Autenticação via token: JACINTOPINTOEREBOLO
  - Implementação específica para linguagem Node.js
- Acrescentar tempo em todas as keys ativas
- Personalizar key por prefixo

### 2.10 Painel Super Admin
- Gerenciamento de permissões de Admin
- Remover permissão de Admin de usuários
- Excluir usuários do sistema
- Acesso a todas as funcionalidades administrativas
- Personalizar key por prefixo

### 2.11 Menu Lateral
Estrutura de navegação com as seguintes seções:
- PRINCIPAL: Dashboard
- KEYS: Gerar Keys, Gerenciar Keys
- CARTEIRA: Transferir Créditos
- PERFIL: Meu Perfil, Revendedor, Reclamações
- ADMIN (apenas para Admin): APIs de Validação
- SUPER ADMIN (apenas para Super Admin): Gerenciar Admins, Excluir Usuários

## 3. Referências Visuais

### 3.1 Imagens de Referência
- 1000186148.png: Interface do menu lateral e estrutura de navegação
- 1000186149.png: Interface do formulário de geração de keys

## 4. Observações
- A interface deve seguir o padrão visual apresentado nas imagens de referência
- O sistema deve validar se o usuário possui créditos suficientes antes de permitir a geração de keys
- Todos os campos marcados com asterisco (*) são obrigatórios
- Não há registro público - todos os usuários são criados por Super Admin ou Revendedores
- Usuários novos iniciam com saldo de 0 créditos
- Revendedores só podem adicionar créditos que possuem em seu próprio saldo
- O usuário pedrosensi está configurado como Super Admin no sistema
- A funcionalidade de compra de créditos foi removida de todos os painéis
- O painel Admin possui acesso exclusivo ao gerenciamento de APIs para validação de keys
- O painel Admin possui nova API específica em Node.js que permite bots/sistemas externos gerarem keys automaticamente através de chamadas API (substituindo a API anterior que estava offline)
- A API para bots requer autenticação via token: JACINTOPINTOEREBOLO
- A API para bots aceita parâmetro de quantidade de dispositivos permitidos
- A API de validação de key permite que bots consultem o status de uma key (ativa, pausada ou expirada)
- A API de gerenciamento de keys possui implementação específica para Node.js, permitindo que bots pausem, resetem e banam keys após o usuário enviar a key
- O painel Super Admin possui funcionalidades exclusivas para remover permissão de Admin e excluir usuários do sistema
- Sistema desconta créditos automaticamente após a geração de keys
- Tabela de créditos por validade:
  - 1 dia: 5 créditos
  - 7 dias: 10 créditos
  - 15 dias: 20 créditos
  - 30 dias: 30 créditos
- Keys são geradas com prefixo personalizado seguido de hífen e código aleatório de 5 dígitos
- Funcionalidade de personalizar key por prefixo disponível em todos os painéis
- Painel Admin pode acrescentar tempo em todas as keys ativas
- Gerenciar Keys permite pausar e resetar keys individuais